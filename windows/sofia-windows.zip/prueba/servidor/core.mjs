// Conector de Sofía: núcleo independiente del hosting (solo Request/Response y Web Crypto estándar).
// Lo usan servidor.mjs (Node: tu PC, Render, Railway, VPS…) y cloudflare/worker.mjs (Cloudflare gratis).
//
// Hace de puente entre la app (que vive en el teléfono) y servicios que exigen un servidor:
//  - Datos:      respaldo/sincronización de la app.
//  - WhatsApp:   webhook oficial de Meta (mensajes entrantes con firma verificada), envío de texto y
//                plantillas por la API de WhatsApp Business (Cloud API), fotos/documentos recibidos.
//  - Messenger:  mensajes de la página de Facebook (mismo buzón).
//  - Facebook:   publicar en la página (texto o foto).
//  - Instagram:  publicar fotos en la cuenta profesional ligada a la página.
// Además trabaja SOLO, aunque la app esté cerrada, y SIN IA (reglas fijas, gratis):
//  - Vendedora:    asistente de ventas de autos (js/vendedor.js): inventario con foto y precio, cotización de
//                  crédito, cita para prueba de manejo y pase al asesor, con un menú por números.
//  - Agente:       o, si la vendedora está apagada, bienvenida, aviso de fuera de horario y reglas por palabra.
//  - Prospectos:   guarda a cada contacto nuevo para que la app lo convierta en cliente.
//  - Programador:  publica en Facebook/Instagram a la hora indicada (runScheduled, lo llama un temporizador).
// Los tokens de Meta viven SOLO aquí (variables de entorno/secretos), nunca en el teléfono.
//
// Variables: SOFIA_TOKEN (clave de la app) · META_APP_SECRET · META_VERIFY_TOKEN · WA_TOKEN ·
// WA_PHONE_NUMBER_ID · WA_WABA_ID · FB_PAGE_ID · FB_PAGE_TOKEN · IG_USER_ID (Instagram; usa FB_PAGE_TOKEN) ·
// PUBLIC_URL (dirección pública del conector, para que Instagram descargue las fotos) · META_GRAPH_URL (opcional) ·
// ANTHROPIC_API_KEY y ANTHROPIC_MODEL (opcionales: la IA de la vendedora, solo para lo que el menú no entiende).

import { decidir, VENTAS_BASE, contienePalabra, primerNombre, rellenar, promptIA, aplicarIA, ESQUEMA_IA, horariosLibres, pesos, cifras } from "../js/vendedor.js";
import { iaPorApi } from "./ia-cloudflare.mjs";
import { modeloEn, mensajePara } from "../js/ordenes.js";
import { entenderOrden, leerCuando, cuandoTexto, buscarCliente, peticionesDe, AYUDA_JARVIS } from "../js/jarvis.js";

export const VERSION = "conector-1.2";
const MAX_MSGS = 500;

const CORS = { "access-control-allow-origin": "*", "access-control-allow-methods": "GET, POST, OPTIONS", "access-control-allow-headers": "content-type" };
const json = (body, status = 200) => new Response(JSON.stringify(body), { status, headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store", ...CORS } });
const fail = (error, status = 400) => json({ ok: false, error }, status);
/** Error de datos que mandó la app (responde 400, no 502). */
const invalido = (msg) => Object.assign(new Error(msg), { status: 400 });
/** El almacén puede no saber borrar (servidor.mjs): entonces se deja vacío. */
const borrar = (store, key) => (store.delete ? store.delete(key) : store.put(key, null));
/** Hora actual; las pruebas la fijan con handle(…, { ahora }). */
function ahoraDe(opciones) {
  const v = typeof opciones?.ahora === "function" ? opciones.ahora() : opciones?.ahora;
  return v ? new Date(v) : new Date();
}

const enc = new TextEncoder();
function sameSecret(a, b) {
  const x = enc.encode(String(a ?? ""));
  const y = enc.encode(String(b ?? ""));
  if (!y.length || x.length !== y.length) return false;
  let d = 0;
  for (let i = 0; i < x.length; i++) d |= x[i] ^ y[i];
  return d === 0;
}

async function hmacHex(secret, body) {
  const key = await crypto.subtle.importKey("raw", enc.encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const sig = new Uint8Array(await crypto.subtle.sign("HMAC", key, body));
  return [...sig].map((b) => b.toString(16).padStart(2, "0")).join("");
}

// ───────── Datos de Meta (y la IA del servidor) guardados desde la app ─────────
// conexion:meta → { WA_TOKEN, WA_PHONE_NUMBER_ID, … } Lo que se guarda aquí manda sobre las variables del servidor,
// así se configura todo desde Más → Conexiones sin volver a desplegar. La app nunca lo vuelve a leer: solo ve si está.
const DESDE_APP = {
  WA_TOKEN: /^\S{20,600}$/, WA_PHONE_NUMBER_ID: /^\d{1,25}$/, WA_WABA_ID: /^\d{1,25}$/, META_APP_SECRET: /^[a-f0-9]{16,64}$/i,
  META_VERIFY_TOKEN: /^[\w.-]{6,100}$/, FB_PAGE_ID: /^\d{1,25}$/, FB_PAGE_TOKEN: /^\S{20,600}$/, IG_USER_ID: /^\d{1,25}$/,
  ASESOR_WHATSAPP: /^\d{10,15}$/, ANTHROPIC_API_KEY: /^sk-ant-\S{10,300}$/, ANTHROPIC_MODEL: /^claude-[a-z0-9-]{2,60}$/, PUBLIC_URL: /^https:\/\/[^\s/?#]+(\/[^\s?#]*)?$/,
  META_APP_ID: /^\d{5,25}$/, META_ES_CONFIG_ID: /^\d{5,25}$/, // registro integrado de Meta (coexistencia)
  CF_ACCOUNT_ID: /^[a-f0-9]{32}$/i, CF_API_TOKEN: /^\S{20,600}$/, // Workers AI REST API; el secreto nunca se devuelve a la app
  LOCAL_AI_URL: /^https?:\/\/[^\s?#]+$/, LOCAL_AI_MODEL: /^[\w.:/-]{2,80}$/, LOCAL_AI_KEY: /^\S{4,300}$/, // IA local (Ollama) en otro equipo
};
const SECRETOS = new Set(["WA_TOKEN", "META_APP_SECRET", "FB_PAGE_TOKEN", "ANTHROPIC_API_KEY", "CF_API_TOKEN", "LOCAL_AI_KEY"]);

async function conConexion(env, store) {
  const d = (await store.get("conexion:meta")) ?? {};
  const extra = Object.fromEntries(Object.keys(DESDE_APP).filter((k) => typeof d[k] === "string" && d[k]).map((k) => [k, d[k]]));
  return Object.keys(extra).length ? { ...env, ...extra } : env;
}

/** Guarda lo que mande la app (vacío = borrar ese dato). Si nadie definió el token de verificación, se inventa uno. */
async function guardarConexion(env, store, datos) {
  if (!datos || typeof datos !== "object" || Array.isArray(datos)) throw invalido("Faltan los datos");
  const actual = (await store.get("conexion:meta")) ?? {};
  for (const [k, v] of Object.entries(datos)) {
    if (!Object.hasOwn(DESDE_APP, k)) throw invalido(`Dato desconocido: ${k}`);
    const t = String(v ?? "").trim().replace(/\/+$/, "");
    if (!t) { delete actual[k]; continue; }
    if (!DESDE_APP[k].test(t)) throw invalido(`${k} no tiene el formato esperado`);
    actual[k] = t;
  }
  if (!actual.META_VERIFY_TOKEN && !env.META_VERIFY_TOKEN) actual.META_VERIFY_TOKEN = `sofia-${nuevoId().slice(0, 16)}`;
  await store.put("conexion:meta", actual);
}

/** Qué datos hay (y de dónde), sin devolver nunca un secreto; más lo que hay que pegar en Meta. */
async function vistaConexion(env, store, base) {
  const d = (await store.get("conexion:meta")) ?? {};
  const efectivo = await conConexion(env, store);
  const configurado = Object.fromEntries(Object.keys(DESDE_APP).map((k) => [k, d[k] ? "app" : env[k] ? "servidor" : null]));
  const visibles = Object.fromEntries(Object.keys(DESDE_APP).filter((k) => !SECRETOS.has(k) && efectivo[k]).map((k) => [k, efectivo[k]]));
  return { configurado, valores: visibles, webhook: { url: `${publicBase(efectivo, base)}/webhook/meta`, verifyToken: efectivo.META_VERIFY_TOKEN ?? null } };
}

const graphUrl = (env) => (env.META_GRAPH_URL || "https://graph.facebook.com/v23.0").replace(/\/+$/, "");
const waReady = (env) => Boolean(env.WA_TOKEN && env.WA_PHONE_NUMBER_ID);
const fbReady = (env) => Boolean(env.FB_PAGE_ID && env.FB_PAGE_TOKEN);
const igReady = (env) => Boolean(env.IG_USER_ID && env.FB_PAGE_TOKEN);

async function graph(env, path, { method = "GET", token, body, form } = {}) {
  const res = await fetch(`${graphUrl(env)}/${path}`, {
    method,
    headers: { ...(token ? { authorization: `Bearer ${token}` } : {}), ...(body ? { "content-type": "application/json" } : {}) },
    body: form ?? (body ? JSON.stringify(body) : undefined),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok || data.error) {
    const e = data.error ?? {};
    const mensaje = e.error_user_msg || e.message || `Meta respondió ${res.status}`;
    const referencia = [
      e.code != null ? `código ${e.code}` : "",
      e.error_subcode != null ? `subcódigo ${e.error_subcode}` : "",
      e.fbtrace_id ? `referencia ${e.fbtrace_id}` : "",
    ].filter(Boolean).join(" · ");
    throw new Error(referencia ? `${mensaje} (${referencia})` : mensaje);
  }
  return data;
}

// ───────── Buzón (WhatsApp y Messenger) ─────────
// inbox:index           → { "<canal>:<id>": { channel, id, name, lastAt, lastText, lastDir, lastInAt, count,
//                           lastManualAt?, autoAt? { <huella de la respuesta automática>: fecha } } }
// inbox:c:<canal>:<id>  → [ { id, dir: "in"|"out", type, text, at, media?, status?, auto? } ]

const DIA_MS = 24 * 3600 * 1000;

/** Solo las marcas de respuestas automáticas de los últimos 30 días (esperaHoras no pasa de 720). */
const marcasRecientes = (marcas, hasta) => Object.fromEntries(Object.entries(marcas ?? {}).filter(([, at]) => new Date(hasta) - new Date(at) < 30 * DIA_MS));

/**
 * Guarda un mensaje en su conversación. Devuelve null si ya existía (Meta reintenta: no duplicar)
 * o { prev } con lo que había de esa conversación ANTES de este mensaje (null = primer contacto).
 * autoKey: huella de la respuesta automática enviada (para no repetirla antes de esperaHoras).
 * extra: datos que se guardan junto a la conversación (p. ej. venta: lo que recuerda la vendedora).
 */
async function addMessage(store, channel, peer, name, msg, autoKey, extra) {
  const key = `${channel}:${peer}`;
  const list = (await store.get(`inbox:c:${key}`)) ?? [];
  if (msg.id && list.some((m) => m.id === msg.id)) {
    // Mensaje repetido (p. ej. al traer chats): solo se aprovecha para completar el nombre que faltaba.
    if (name) {
      const index = (await store.get("inbox:index")) ?? {};
      if (index[key] && !index[key].name) { index[key].name = name; await store.put("inbox:index", index); }
      const leads = (await store.get("leads:index")) ?? {};
      if (leads[key] && !leads[key].nombre) { leads[key].nombre = name; await store.put("leads:index", leads); }
    }
    return null;
  }
  list.push(msg);
  if (list.length > MAX_MSGS) list.splice(0, list.length - MAX_MSGS);
  await store.put(`inbox:c:${key}`, list);
  const index = (await store.get("inbox:index")) ?? {};
  const prev = index[key] ?? null;
  const base = prev ?? { channel, id: peer, count: 0 };
  index[key] = {
    ...base,
    name: name || base.name || "",
    lastAt: msg.at,
    lastText: msg.text || (msg.media ? `[${msg.type}]` : ""),
    lastDir: msg.dir,
    lastInAt: msg.dir === "in" ? msg.at : base.lastInAt ?? null,
    count: base.count + 1,
    ...(msg.dir === "out" && !msg.auto ? { lastManualAt: msg.at } : {}),
    ...(autoKey ? { autoAt: marcasRecientes({ ...base.autoAt, [autoKey]: msg.at }, msg.at) } : {}),
    ...(extra ?? {}),
  };
  await store.put("inbox:index", index);
  return { prev };
}

// Meta manda sent → delivered → read (a veces en desorden). "failed" y otros no tienen orden: se guardan siempre.
const ORDEN_ESTADO = { sent: 1, delivered: 2, read: 3 };

async function setStatus(store, channel, peer, id, status) {
  const k = `inbox:c:${channel}:${peer}`;
  const list = await store.get(k);
  const m = list?.find((x) => x.id === id);
  // Sin cambio, o un "delivered" que llega después del "read": no se reescribe (cuida el límite de KV).
  if (!m || m.status === status || ORDEN_ESTADO[status] < ORDEN_ESTADO[m.status]) return;
  m.status = status;
  await store.put(k, list);
}

function waText(m) {
  switch (m.type) {
    case "text": return m.text?.body ?? "";
    case "image": case "video": case "document": case "audio": case "sticker": return m[m.type]?.caption ?? "";
    case "button": return m.button?.text ?? "";
    case "interactive": return m.interactive?.button_reply?.title ?? m.interactive?.list_reply?.title ?? "";
    case "location": return `📍 ${m.location?.latitude},${m.location?.longitude}`;
    case "reaction": return m.reaction?.emoji ?? "";
    default: return `[${m.type}]`;
  }
}

// ───────── Agente sin IA: respuestas automáticas por reglas ─────────
// agente:config   → ver AGENTE_BASE (la app lo edita con /api/agente/config)
// agente:errores  → [ { at, canal, id, error } ]  últimos envíos automáticos que fallaron
//
// Por cada mensaje entrante NUEVO se elige, en este orden, la primera respuesta que no se le haya
// mandado a ese contacto en las últimas esperaHoras: bienvenida (primer contacto) → fuera de horario →
// reglas por palabra. Nunca más de una respuesta automática por mensaje.

// De fábrica: contesta por Mario Abarca (Honda), sola y con IA (gratis de Cloudflare), sin configurar nada.
const PERFIL = 5; // sube cuando cambia lo de fábrica y hay que pasar las configuraciones guardadas a la nueva forma
const AGENTE_BASE = {
  perfil: PERFIL,
  activo: true,
  zonaHoraria: "America/Monterrey",
  horario: { dias: [1, 2, 3, 4, 5, 6], inicio: "09:00", fin: "19:00" }, // 0 = domingo, 1 = lunes … 6 = sábado
  bienvenida: "¡Hola {nombre}! Gracias por escribir. En un momento te atiendo.",
  fueraDeHorario: "¡Hola {nombre}! Soy Mario Abarca, de Honda. Cuéntame, ¿qué modelo estás buscando?",
  reglas: [], // [ { palabras: ["precio", "cuánto cuesta"], respuesta: "…" } ]
  esperaHoras: 12, // no repetir la misma respuesta automática al mismo contacto antes de N horas
  pausaMinutos: 30, // si el asesor contestó a mano hace menos de N minutos, el agente no interrumpe
  asesor: "Mario Abarca",
  agencia: "Honda",
  marca: "Honda",
  direccion: "", // la manda Sofía cuando preguntan «¿dónde están?»
  mapa: "", // link de Google Maps (https://…)
  ventas: { ...VENTAS_BASE, ia: true }, // vendedora (agenda citas); apagada = solo lo de arriba
  estilo: { ejemplos: [], deChats: [], notas: "" }, // cómo escribe el asesor: con IA, Sofía habla como él
  corridas: "", // corridas del asesor (enganche 20/30/40/50 %), tal cual: con IA son las únicas cifras de crédito que da
};
const MAX_CORRIDAS = 12000;
const MAX_REGLAS = 50;
const MAX_TEXTO_AUTO = 1000;
// Con 0 horas, dos contestadores automáticos (el nuestro y el de otro negocio) se responderían sin fin.
const MIN_ESPERA_HORAS = 1;
const HORA = /^([01]\d|2[0-3]):[0-5]\d$/;
// Tipos de mensaje que no llevan respuesta (reacciones, avisos del sistema, mensajes que WhatsApp no soporta).
const SIN_RESPUESTA = new Set(["reaction", "system", "unsupported", "errors", "ephemeral"]);
const DIAS = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 };

function zonaValida(zona) {
  try { new Intl.DateTimeFormat("en-US", { timeZone: zona }); return true; } catch { return false; }
}

function textoAuto(v, campo) {
  const t = String(v ?? "").trim();
  if (t.length > MAX_TEXTO_AUTO) throw invalido(`${campo}: máximo ${MAX_TEXTO_AUTO} caracteres`);
  return t;
}

function numeroEntre(v, porDefecto, min, max) {
  const n = Number(v ?? porDefecto);
  return Number.isFinite(n) && n >= 0 ? Math.min(Math.max(n, min), max) : porDefecto;
}

/** Valida y completa la configuración que manda la app (lo que falte queda como estaba). */
function normalizarConfig(c) {
  const h = { ...AGENTE_BASE.horario, ...(c.horario ?? {}) };
  if (!HORA.test(h.inicio) || !HORA.test(h.fin)) throw invalido("El horario va como HH:MM, por ejemplo 09:00 y 19:00");
  if (!Array.isArray(h.dias)) throw invalido("Los días del horario deben ser una lista");
  const numeros = h.dias.map((d) => (/^\s*[0-7]\s*$/.test(String(d)) ? Number(d) % 7 : NaN)); // 7 también es domingo
  if (numeros.some(Number.isNaN)) throw invalido("Los días del horario van del 0 (domingo) al 6 (sábado)");
  const dias = [...new Set(numeros)].sort((a, b) => a - b);
  const zonaHoraria = String(c.zonaHoraria || AGENTE_BASE.zonaHoraria);
  if (!zonaValida(zonaHoraria)) throw invalido(`Zona horaria desconocida: ${zonaHoraria}`);
  if (!Array.isArray(c.reglas)) throw invalido("Las reglas deben ser una lista");
  if (c.reglas.length > MAX_REGLAS) throw invalido(`Máximo ${MAX_REGLAS} reglas`);
  const reglas = c.reglas.map((r, i) => {
    const palabras = (Array.isArray(r?.palabras) ? r.palabras : String(r?.palabras ?? "").split(",")).map((p) => String(p).trim()).filter(Boolean);
    const respuesta = textoAuto(r?.respuesta, `Regla ${i + 1}`);
    if (!palabras.length || !respuesta) throw invalido(`La regla ${i + 1} necesita palabras y respuesta`);
    return { palabras, respuesta };
  });
  return {
    activo: Boolean(c.activo),
    zonaHoraria,
    horario: { dias, inicio: h.inicio, fin: h.fin },
    bienvenida: textoAuto(c.bienvenida, "Bienvenida"),
    fueraDeHorario: textoAuto(c.fueraDeHorario, "Fuera de horario"),
    reglas,
    esperaHoras: numeroEntre(c.esperaHoras, AGENTE_BASE.esperaHoras, MIN_ESPERA_HORAS, 720),
    pausaMinutos: numeroEntre(c.pausaMinutos, AGENTE_BASE.pausaMinutos, 0, 1440),
    asesor: String(c.asesor ?? "").trim().slice(0, 80),
    agencia: String(c.agencia ?? "").trim().slice(0, 80),
    marca: String(c.marca ?? AGENTE_BASE.marca).trim().slice(0, 40) || AGENTE_BASE.marca,
    direccion: String(c.direccion ?? "").trim().slice(0, 200),
    mapa: /^https:\/\/\S+$/.test(String(c.mapa ?? "").trim()) ? String(c.mapa).trim().slice(0, 300) : "",
    ventas: normalizarVentas(c.ventas),
    estilo: normalizarEstilo(c.estilo),
    corridas: textoCorridas(c.corridas),
    perfil: PERFIL,
  };
}

function textoCorridas(v) {
  const t = String(v ?? "").replace(/\r\n?/g, "\n").trim();
  if (t.length > MAX_CORRIDAS) throw invalido(`Corridas: máximo ${MAX_CORRIDAS} caracteres`);
  return t;
}

/** Cómo escribe el asesor (mensajes reales suyos de «Mi estilo de venta»), para que Sofía hable como él. */
function normalizarEstilo(e = {}) {
  const lista = (x) => (Array.isArray(x) ? x : []).map((t) => String(t ?? "").trim().slice(0, 300)).filter((t) => t.length >= 3).slice(0, 40);
  // deChats: lo aprende el servidor del historial de WhatsApp Business (coexistencia); la app no lo manda.
  return { ejemplos: lista(e?.ejemplos), deChats: lista(e?.deChats), notas: String(e?.notas ?? "").trim().slice(0, 600) };
}

function normalizarVentas(v = {}) {
  const b = AGENTE_BASE.ventas;
  const entre = (x, porDefecto, min, max) => { const n = Number(x ?? porDefecto); return Number.isFinite(n) ? Math.min(Math.max(n, min), max) : porDefecto; };
  const plazos = Array.isArray(v.plazos) ? [...new Set(v.plazos.map(Number).filter((n) => Number.isInteger(n) && n >= 6 && n <= 96))].sort((x, y) => x - y).slice(0, 6) : b.plazos;
  return {
    activo: v.activo === undefined ? b.activo : Boolean(v.activo),
    tasaAnual: Math.round(entre(v.tasaAnual, b.tasaAnual, 0, 80) * 100) / 100,
    engancheMinimo: entre(v.engancheMinimo, b.engancheMinimo, 0, 90),
    plazos: plazos.length ? plazos : b.plazos,
    horasConAsesor: entre(v.horasConAsesor, b.horasConAsesor, 0, 168),
    presentacion: textoAuto(v.presentacion, "Presentación"),
    ia: v.ia === undefined ? b.ia : Boolean(v.ia),
    seguimiento: v.seguimiento === undefined ? b.seguimiento : Boolean(v.seguimiento),
    resumenDiario: v.resumenDiario === undefined ? b.resumenDiario : Boolean(v.resumenDiario),
    soloNuevos: v.soloNuevos !== false, // modo seguro: solo prospectos nuevos que Mario no ha tocado
  };
}

async function leerConfig(store) {
  let c = await store.get("agente:config");
  // Configuración guardada antes de la Sofía de Mario en Honda (no trae «marca»): pasa a la nueva forma de trabajar,
  // contestando sola y con IA, con Mario y Honda donde estaba vacío.
  if (c && !c.marca) c = { ...c, activo: true, asesor: c.asesor || AGENTE_BASE.asesor, agencia: c.agencia || AGENTE_BASE.agencia, marca: AGENTE_BASE.marca, ventas: { ...(c.ventas ?? {}), activo: true, ia: true } };
  // Lo de fábrica antes era «Mario» o «Lic. Mario Abarca» y «Soy Sofía, asistente de…»: ahora contesta por Mario Abarca.
  if (c && (c.perfil ?? 1) < PERFIL) {
    const perfilAnterior = c.perfil ?? 1;
    c = { ...c, perfil: PERFIL, asesor: ["", "Mario", "Lic. Mario Abarca"].includes(c.asesor ?? "") ? AGENTE_BASE.asesor : c.asesor };
    // La versión anterior callaba 12 h después de pasar un chat a Mario. Sofía ahora retoma cuando el cliente vuelve.
    if (perfilAnterior < 5 && Number(c.ventas?.horasConAsesor ?? 12) === 12) c.ventas = { ...c.ventas, horasConAsesor: 0 };
    if (/Soy Sofía/i.test(c.ventas?.presentacion ?? "")) c.ventas = { ...c.ventas, presentacion: "" };
    if (/en este momento estoy fuera de horario/i.test(c.fueraDeHorario ?? "")) c.fueraDeHorario = AGENTE_BASE.fueraDeHorario;
  }
  return { ...AGENTE_BASE, ...(c ?? {}), horario: { ...AGENTE_BASE.horario, ...(c?.horario ?? {}) }, ventas: { ...AGENTE_BASE.ventas, ...(c?.ventas ?? {}) } };
}

/** ¿La hora dada cae dentro del horario de atención, en la zona horaria de la agencia? */
function enHorario(cfg, ahora) {
  let partes;
  try {
    partes = new Intl.DateTimeFormat("en-US", { timeZone: cfg.zonaHoraria, weekday: "short", hour: "2-digit", minute: "2-digit", hourCycle: "h23" }).formatToParts(ahora);
  } catch { return true; } // zona inválida: mejor no avisar "fuera de horario" por error
  const p = Object.fromEntries(partes.map((x) => [x.type, x.value]));
  const { dias, inicio, fin } = cfg.horario;
  if (!dias.includes(DIAS[p.weekday])) return false;
  const hhmm = `${p.hour}:${p.minute}`;
  if (inicio === fin) return true; // todo el día
  return inicio < fin ? hhmm >= inicio && hhmm < fin : hhmm >= inicio || hhmm < fin; // turno que cruza la medianoche
}

/** Huella corta de una respuesta (FNV-1a): identifica "la misma respuesta" aunque cambie el orden de las reglas. */
function huella(s) {
  let h = 0x811c9dc5;
  for (let i = 0; i < s.length; i++) h = Math.imul(h ^ s.charCodeAt(i), 0x01000193);
  return (h >>> 0).toString(36);
}

function elegirRespuesta(cfg, e, ahora) {
  const candidatas = [];
  if (e.primero && cfg.bienvenida) candidatas.push(cfg.bienvenida);
  if (cfg.fueraDeHorario && !enHorario(cfg, ahora)) candidatas.push(cfg.fueraDeHorario);
  for (const r of cfg.reglas) if (r.palabras.some((p) => contienePalabra(e.texto, p))) candidatas.push(r.respuesta);
  const espera = Math.max(Number(cfg.esperaHoras) || 0, MIN_ESPERA_HORAS) * 3600 * 1000;
  return candidatas.find((t) => {
    const antes = e.prev?.autoAt?.[huella(t)];
    return !antes || ahora - new Date(antes) >= espera;
  });
}

/**
 * Contesta solo, si toca. Devuelve true si intentó mandar una respuesta.
 * Un envío fallido se anota en agente:errores y NO rompe el webhook (Meta debe recibir 200).
 */
async function responderSolo(env, store, cfg, e, ahora) {
  if (!cfg.activo) return false;
  if (ahora - new Date(e.at) > DIA_MS) return false; // mensaje viejo (Meta lo reenvió tarde): ya no se contesta
  const pausa = cfg.pausaMinutos * 60 * 1000;
  if (pausa && e.prev?.lastManualAt && ahora - new Date(e.prev.lastManualAt) < pausa) return false;
  if (contestaElAsesor(cfg, e, ahora)) return false;
  const plantilla = elegirRespuesta(cfg, e, ahora);
  if (!plantilla) return false;
  const text = rellenar(plantilla, { nombre: primerNombre(e.nombre), asesor: cfg.asesor, agencia: cfg.agencia || "la agencia" }); // sin nombre: "Estamos en la agencia.", no "Estamos en."
  if (!text) return false;
  try {
    await sendMessage(env, store, { channel: e.canal, to: e.id, text }, { ahora, autoKey: huella(plantilla) });
  } catch (err) {
    const errores = (await store.get("agente:errores")) ?? [];
    errores.unshift({ at: ahora.toISOString(), canal: e.canal, id: e.id, error: err.message ?? String(err) });
    await store.put("agente:errores", errores.slice(0, 20));
  }
  return true;
}

// ───────── Vendedora: asistente de ventas de autos (sin IA) ─────────
// ventas:inventario → [ { id, marca, modelo, version, anio, precio, tipo, km, color, transmision, descripcion,
//                        palabras, disponible, fotoId? } ]  (lo manda la app; la foto vive en media:<fotoId>)
// inbox:index[clave].venta → lo que Sofía recuerda de esa conversación (paso, auto elegido, opciones del menú…)

const MAX_AUTOS = 200;
const MAX_FOTO_AUTO = 5 * 1024 * 1024; // límite de WhatsApp para imágenes

// Respuestas que en chats reales hicieron más daño que bien: mejor callarse y avisar a Mario.
const CALLA_SOFIA = new Set(["no-entendi", "menu"]);
const DIAS_NUEVO = 3;
/** El saludo automático que Mario tiene en WhatsApp Business (no cuenta como que él ya platicó). */
const esSaludoDeMario = (m) => /soy mario abarca/i.test(m.text ?? "") && /asesor comercial|con qui[eé]n tengo el gusto|buen fin/i.test(m.text ?? "");

/**
 * Modo seguro: Sofía solo atiende prospectos NUEVOS que Mario no ha tocado.
 * - Chat con historia de más de 3 días (cliente actual, trámite, devolución, amigo, familia) → no.
 * - Mario ya escribió a mano (texto, foto, PDF, nota de voz; no su saludo automático) → él lo lleva, no.
 * - Marcado como postventa o personal → no.
 */
export function esProspectoNuevo(platica, ficha, ahora) {
  if (ficha?.postventa || ficha?.personal || ficha?.tipo === "postventa" || ficha?.tipo === "personal") return false;
  const fechas = platica.map((m) => Date.parse(m.at)).filter(Number.isFinite);
  if (fechas.length && ahora - Math.min(...fechas) > DIAS_NUEVO * DIA_MS) return false;
  return !platica.some((m) => m.dir === "out" && !m.auto && !esSaludoDeMario(m));
}

/**
 * Contesta como vendedora (js/vendedor.js), si toca. Devuelve true si intentó mandar algo.
 * Las fotos del inventario solo se mandan con una dirección pública HTTPS (Meta las descarga de ahí).
 */
async function responderVentas(env, store, cfg, e, ahora, base) {
  if (!cfg.activo) return false;
  if (ahora - new Date(e.at) > DIA_MS) return false; // mensaje viejo (Meta lo reenvió tarde): ya no se contesta
  const pausa = cfg.pausaMinutos * 60 * 1000;
  // En el chat de pruebas, un /sofia autorizado puede reanudar el flujo aunque
  // antes hubiera ocurrido un pase al asesor o una intervención manual.
  if (!e.pruebaLocal && pausa && e.prev?.lastManualAt && ahora - new Date(e.prev.lastManualAt) < pausa) return false;
  if (!e.pruebaLocal && contestaElAsesor(cfg, e, ahora)) return false;
  // Amigos, familia y compañeros (lo marcaron las reglas o la IA de fondo): Sofía no les contesta, los atiende Mario.
  const ficha = ((await store.get("leads:index")) ?? {})[`${e.canal}:${e.id}`];
  if (!e.pruebaLocal && ficha?.personal && ficha.fondoMotor) return false; // la IA leyó el chat completo: es personal
  const plática = (await store.get(`inbox:c:${e.canal}:${e.id}`)) ?? [];
  if (!e.pruebaLocal && cfg.ventas.soloNuevos !== false && !esProspectoNuevo(plática, ficha, ahora)) return false;
  const inventario = await inventarioVendedora(store, publicBase(env, base), true);
  const historial = async () => plática.map((m) => ({ dir: m.dir, text: m.text }));
  const libres = await libresDe(store, cfg, ahora);
  const r = await pensarVenta(env, cfg, inventario, e.prev?.venta ?? {}, { texto: e.texto, nombre: e.nombre, primero: e.primero, pruebaLocal: e.pruebaLocal === true }, historial, ahora, libres);
  if (r.errorIA) await anotarError(store, e, `IA: ${r.errorIA}`, ahora);
  if (r.motivo === "personal") r.lead = { ...r.lead, personal: true, tipo: "personal" }; // la IA de fondo lo puede corregir
  // Lo marcaron como personal solo las reglas (por su primer mensaje): si luego pregunta por un auto, se le vende;
  // si no, Sofía sigue sin meterse en la plática.
  // Si no entendió o solo saludaría, no manda nada: el saludo ya lo manda WhatsApp Business y Mario ve el aviso.
  if (!e.pruebaLocal && cfg.ventas.soloNuevos !== false && CALLA_SOFIA.has(r.motivo)) r.respuestas = [];
  if (!e.pruebaLocal && ficha?.personal && !ficha.fondoMotor && r.motivo !== "personal") {
    if (["no-entendi", "menu", "gracias", "emoji", "nombre-dicho", "acuse", ""].includes(r.motivo)) { r.respuestas = []; r.lead = {}; }
    else r.lead = { ...r.lead, personal: false, tipo: "cliente" };
  }
  // Las pruebas del chat propio no generan prospectos, reservas ni notificaciones reales.
  if (!e.pruebaLocal) {
    if (Object.keys(r.lead).length) await actualizarLead(store, e, r.lead, ahora);
    if (r.reserva) await apartarCita(env, store, cfg, e, r, ahora);
    await avisarSiToca(env, store, cfg, e, r, ahora);
    if (env.WA_WEB?.etiquetar && Object.keys(r.lead).length) {
      const etiquetas = [
        r.lead.quiereAsesor && "Asesor",
        (r.lead.cita || r.reserva) && "Cita",
        (r.lead.calor === "caliente" || (r.lead.quiereAsesor && !r.lead.postventa) || r.reserva) && "Caliente",
        r.lead.interes && !r.lead.quiereAsesor && !r.lead.cita && !r.reserva && "Prospecto",
      ].filter(Boolean);
      if (etiquetas.length) await env.WA_WEB.etiquetar({ to: e.id, etiquetas }).catch(() => {});
    }
  }
  for (const [i, m] of r.respuestas.entries()) {
    try {
      await sendMessage(env, store, { channel: e.canal, to: e.id, text: m.texto, ...(m.foto ? { image: m.foto } : {}) },
        { ahora, autoKey: `venta:${r.motivo}`, indice: i === r.respuestas.length - 1 ? { venta: r.conv } : undefined });
    } catch (err) {
      await anotarError(store, e, err.message ?? String(err), ahora);
      break;
    }
  }
  return r.respuestas.length > 0;
}

/** Inventario para la vendedora, con la foto como URL pública (WhatsApp solo descarga de HTTPS). */
async function inventarioVendedora(store, pub, soloHttps) {
  const ok = !soloHttps || pub.startsWith("https://");
  return ((await store.get("ventas:inventario")) ?? []).map((a) => ({ ...a, foto: a.fotoId && ok ? `${pub}/media/${a.fotoId}` : null }));
}

// ───────── Agenda de citas ─────────
// agenda:citas → [ { id (ISO del inicio), canal, cliente, nombre, interes, resumen, creada, estado: "apartada"|"cancelada" } ]

async function citasActivas(store, ahora) {
  return ((await store.get("agenda:citas")) ?? []).filter((x) => x.estado !== "cancelada" && new Date(x.id) > ahora - 2 * 3600 * 1000);
}

/** Horarios libres de los próximos días según el horario de la agencia y lo ya apartado. */
async function libresDe(store, cfg, ahora) {
  const ocupadas = (await citasActivas(store, ahora)).map((x) => x.id);
  return horariosLibres({ horario: cfg.horario, zonaHoraria: cfg.zonaHoraria, ocupadas, ahora });
}

/** Aparta el horario (si nadie lo tomó en el inter) y le avisa al asesor por WhatsApp si dejó su número. */
async function apartarCita(env, store, cfg, e, r, ahora) {
  const citas = (await store.get("agenda:citas")) ?? [];
  if (citas.some((x) => x.id === r.reserva.id && x.estado !== "cancelada")) return false;
  const lead = ((await store.get("leads:index")) ?? {})[`${e.canal}:${e.id}`] ?? {};
  const cita = { id: r.reserva.id, texto: r.reserva.texto, canal: e.canal, cliente: e.id, nombre: lead.nombreCliente || e.nombre || "", interes: lead.interes ?? "", resumen: lead.resumen ?? "", creada: ahora.toISOString(), estado: "apartada" };
  // Se libera el horario que tenía antes este mismo cliente (si cambió la cita).
  for (const x of citas) if (x.canal === e.canal && x.cliente === e.id && x.estado === "apartada") x.estado = "cancelada";
  citas.push(cita);
  await store.put("agenda:citas", citas.filter((x) => new Date(x.id) > ahora - 30 * DIA_MS).slice(-500));
  return true;
}

/**
 * El aviso al asesor sale una vez por cita, cuando ya hay con qué: el nombre del cliente o el pase al asesor.
 * Lleva lo último que Sofía sabe (modelo, resumen).
 */
async function avisarSiToca(env, store, cfg, e, r, ahora) {
  const citas = (await store.get("agenda:citas")) ?? [];
  const cita = citas.find((x) => x.canal === e.canal && x.cliente === e.id && x.estado === "apartada" && !x.avisada);
  const lead = ((await store.get("leads:index")) ?? {})[`${e.canal}:${e.id}`] ?? {};
  if (!cita) {
    // Sin cita pero pidió que lo atienda el asesor (su corrida por aquí, negociar…): también le llega, una vez cada 12 h.
    // También cuando preguntó algo que Sofía no sabe con certeza (colores, existencia, ubicación…) o trae auto a cuenta:
    // Sofía siguió la plática y a Mario le llega la pregunta para contestarla él (máximo una vez por hora por chat).
    if (!r.lead.quiereAsesor && !r.lead.duda) return;
    const vigilado = await store.get(`aviso:pide:ultimo:${e.canal}:${e.id}`);
    if (vigilado && ahora - new Date(vigilado) < 30 * 60e3) return; // ya le llegó a Mario el aviso con lo que pide
    const clave = `aviso:${r.lead.quiereAsesor ? "" : "duda:"}${e.canal}:${e.id}`;
    const antes = await store.get(clave);
    if (antes && ahora - new Date(antes) < (r.lead.quiereAsesor ? 12 : 1) * 3600 * 1000) return;
    await store.put(clave, ahora.toISOString());
    await avisarAsesor(env, store, cfg, e, null, ahora, r.lead.quiereAsesor ? lead : { ...lead, quiereAsesor: false, duda: r.lead.duda });
    return;
  }
  if (!lead.nombreCliente && !r.lead.quiereAsesor) return;
  Object.assign(cita, { nombre: lead.nombreCliente || cita.nombre, interes: lead.interes || cita.interes, resumen: lead.resumen || cita.resumen, avisada: true });
  await store.put("agenda:citas", citas);
  await avisarAsesor(env, store, cfg, e, cita, ahora, lead);
}

// ───────── Modo Jarvis: recordatorios, notas, órdenes libres y avisos de lo que Sofía no puede dar ─────────
// jarvis:recordatorios → [ { id, texto, at, clave?, nombre?, hecho, avisado, creado } ]
// jarvis:pendiente     → { texto, vence } (pidió un recordatorio sin decir cuándo: la siguiente orden lo completa)

/** Manda un WhatsApp a Mario (su chat «Tú» con WhatsApp vinculado, o ASESOR_WHATSAPP). Devuelve true si salió. */
async function avisarAMario(env, store, texto, ahora) {
  const vinculado = env.WA_WEB?.estado?.();
  const numero = String(env.ASESOR_WHATSAPP || (vinculado?.ok ? vinculado.phone : "") || "").replace(/\D/g, "");
  if (!numero || !(vinculado?.ok || waReady(env))) return false;
  try {
    await sendMessage(env, store, { channel: "wa", to: numero.length === 10 ? `52${numero}` : numero, text: texto }, { ahora });
    return true;
  } catch (err) { console.warn(`Aviso a Mario: ${err.message ?? err}`); return false; }
}

const fichaCorta = (clave, l = {}) => [
  `${l.nombreCliente || l.nombre || "Cliente"} · …${String(clave).slice(-4)}`,
  l.interes && `🚗 ${l.interes}${l.calor ? ` · ${l.calor}` : ""}${l.formaPago ? ` · ${l.formaPago}` : ""}`,
  l.resumen && `🧠 ${l.resumen}`,
  l.siguiente && `➡️ ${l.siguiente}`,
  l.notas?.length && `📝 ${l.notas.slice(-3).map((n) => n.texto).join(" · ")}`,
  clave.startsWith("wa:") && `Abrir chat: https://wa.me/${clave.slice(3)}`,
].filter(Boolean).join("\n");

async function recordatoriosPendientes(store) {
  return ((await store.get("jarvis:recordatorios")) ?? []).filter((r) => !r.hecho).sort((a, b) => a.at - b.at);
}

/** Lo que Mario le dice a Sofía (app o chat «Tú»). Devuelve { tipo, respuesta } o { tipo: "masivo" } para el flujo de envíos. */
export async function ordenJarvis(env, store, texto, ahora = new Date(), { conIA = true } = {}) {
  const cfg = await leerConfig(store);
  const tz = cfg.zonaHoraria || "America/Monterrey";
  const t0 = ahora.getTime();
  let o = entenderOrden(texto, t0, tz);
  // «recuérdame marcarle a Juan» → «¿para cuándo?» → «mañana a las 10»
  const pend = await store.get("jarvis:pendiente");
  if (pend && pend.vence > t0 && (!o || o.accion === "falta-cuando" || o.accion === "citas")) {
    const c = leerCuando(texto, t0, tz);
    if (c) { o = { accion: "recordar", texto: pend.texto, at: c.at }; await borrar(store, "jarvis:pendiente"); }
  }
  // Lo que las reglas no entienden: la IA lo traduce a una de las órdenes conocidas (nunca inventa datos).
  if (!o && conIA && motoresIA(env, "chat").length) {
    const r = await preguntarIA(env, {
      system: `Traduce la orden de ${cfg.asesor || "Mario"} (asesor de ventas de autos) a una acción. Acciones: recordar (quiere que le recuerdes algo; en «cuando» copia la fecha/hora tal cual la dijo, ej. «mañana a las 10»), nota (anotar un dato de un cliente), cliente (pregunta por un cliente), citas (pregunta por citas; dia 0 hoy, 1 mañana), personal (un contacto no es cliente), apagar, prender, recordatorios, masivo (mandar mensajes a varios clientes), ninguna (no es una orden). En «texto» va la tarea o la nota sin la fecha.`,
      messages: [{ role: "user", content: String(texto).slice(0, 500) }],
    }, { tarea: "chat", max: 150, esquema: { type: "object", properties: { accion: { type: "string" }, texto: { type: "string" }, cuando: { type: "string" }, dia: { type: "number" } }, required: ["accion", "texto", "cuando"], additionalProperties: false } }).catch(() => null);
    if (r?.accion === "recordar") {
      const c = leerCuando(r.cuando || texto, t0, tz);
      o = c ? { accion: "recordar", texto: r.texto || texto, at: c.at } : { accion: "falta-cuando", texto: r.texto || texto };
    } else if (["nota", "cliente", "personal"].includes(r?.accion)) o = { accion: r.accion, texto: r.accion === "nota" ? r.texto || texto : texto };
    else if (r?.accion === "citas") o = { accion: "citas", dia: r.dia === 1 ? 1 : 0 };
    else if (["apagar", "prender", "recordatorios", "masivo"].includes(r?.accion)) o = { accion: r.accion };
  }
  if (!o) return { tipo: "no-entendi", respuesta: `No te entendí 🙈. Esto es lo que puedo hacer:\n\n${AYUDA_JARVIS}` };
  const leads = (await store.get("leads:index")) ?? {};
  const quien = (x) => buscarCliente(x, leads);
  switch (o.accion) {
    case "ayuda": return { tipo: "ayuda", respuesta: AYUDA_JARVIS };
    case "masivo": return { tipo: "masivo" };
    case "falta-cuando":
      await store.put("jarvis:pendiente", { texto: o.texto, vence: t0 + 15 * 60e3 });
      return { tipo: "pregunta", respuesta: `¿Para cuándo te recuerdo «${o.texto}»? (ej. «mañana a las 10», «en 2 horas», «el jueves en la tarde»)` };
    case "recordar": {
      const c = quien(o.texto);
      const lista = (await store.get("jarvis:recordatorios")) ?? [];
      const nuevo = { id: `r${t0.toString(36)}${Math.random().toString(36).slice(2, 5)}`, texto: o.texto, at: o.at, hecho: false, avisado: false, creado: ahora.toISOString(), ...(c ? { clave: c.clave, nombre: c.nombreCliente || c.nombre || "" } : {}) };
      await store.put("jarvis:recordatorios", [...lista.filter((r) => !r.hecho || t0 - r.at < 30 * DIA_MS), nuevo].slice(-300));
      return { tipo: "recordatorio", recordatorio: nuevo, respuesta: `⏰ Listo, te lo recuerdo ${cuandoTexto(o.at, ahora, tz)}: «${o.texto}».${c ? `\nCliente: ${c.nombreCliente || c.nombre || "…" + c.clave.slice(-4)}${c.ambiguo ? ` (hay ${c.ambiguo} con ese nombre; tomé el más reciente)` : ""}` : ""}` };
    }
    case "recordatorios": {
      const p = await recordatoriosPendientes(store);
      if (!p.length) return { tipo: "lista", respuesta: "No tienes recordatorios pendientes 👌" };
      return { tipo: "lista", recordatorios: p, respuesta: `📋 Tus recordatorios:\n${p.map((r, i) => `${i + 1}. ${cuandoTexto(r.at, ahora, tz)} — ${r.texto}${r.avisado ? " (ya te avisé)" : ""}`).join("\n")}\n\nPara quitar uno: *sofia listo 2*` };
    }
    case "hecho": {
      const lista = (await store.get("jarvis:recordatorios")) ?? [];
      const p = lista.filter((r) => !r.hecho).sort((a, b) => a.at - b.at);
      const c = o.n ? null : quien(o.texto);
      const elegidos = o.n ? [p[o.n - 1]].filter(Boolean) : c ? p.filter((r) => r.clave === c.clave) : p.filter((r) => r.avisado).slice(-1);
      if (!elegidos.length) return { tipo: "lista", respuesta: o.n ? `No hay recordatorio ${o.n}. Escribe *sofia recordatorios* para ver la lista.` : "¿Cuál? Escribe *sofia recordatorios* y luego *sofia listo 2*." };
      for (const r of elegidos) r.hecho = true;
      await store.put("jarvis:recordatorios", lista);
      return { tipo: "hecho", respuesta: `✅ Hecho: ${elegidos.map((r) => `«${r.texto}»`).join(", ")}.` };
    }
    case "nota": {
      const c = quien(o.texto);
      if (!c) {
        const notas = (await store.get("jarvis:notas")) ?? [];
        await store.put("jarvis:notas", [...notas, { texto: o.texto, at: ahora.toISOString() }].slice(-200));
        return { tipo: "nota", respuesta: `📝 Anotado: «${o.texto}». (No vi a qué cliente va; quedó en tus notas generales.)` };
      }
      const l = leads[c.clave];
      l.notas = [...(l.notas ?? []), { texto: o.texto, at: ahora.toISOString() }].slice(-30);
      await store.put("leads:index", leads);
      return { tipo: "nota", respuesta: `📝 Anotado en la ficha de ${l.nombreCliente || l.nombre || "…" + c.clave.slice(-4)}: «${o.texto}».` };
    }
    case "cliente": {
      const c = quien(o.texto);
      if (!c) return { tipo: "cliente", respuesta: "No encontré a ese cliente. Dime su nombre como está en WhatsApp o los últimos 4 dígitos de su número." };
      const chat = (await store.get(`inbox:c:${c.clave}`)) ?? [];
      const ult = chat.filter((m) => String(m.text ?? "").trim()).slice(-3).map((m) => `${m.dir === "in" ? "Él/ella" : m.auto ? "Sofía" : "Tú"}: ${String(m.text).replace(/\s+/g, " ").slice(0, 120)}`).join("\n");
      const recs = (await recordatoriosPendientes(store)).filter((r) => r.clave === c.clave);
      return { tipo: "cliente", respuesta: `🔎 ${fichaCorta(c.clave, leads[c.clave])}${recs.length ? `\n⏰ ${recs.map((r) => `${cuandoTexto(r.at, ahora, tz)}: ${r.texto}`).join(" · ")}` : ""}${ult ? `\n\nÚltimo:\n${ult}` : ""}${c.ambiguo ? `\n(Hay ${c.ambiguo} con ese nombre; te enseño el más reciente.)` : ""}` };
    }
    case "personal": case "cliente-si": {
      const c = quien(o.texto);
      if (!c) return { tipo: "cliente", respuesta: "¿Quién? Dime su nombre como está en WhatsApp o los últimos 4 dígitos." };
      const personal = o.accion === "personal";
      Object.assign(leads[c.clave], { personal, tipo: personal ? "personal" : "cliente", fondoMotor: "mario", tipoManual: true, ...(personal ? {} : { postventa: false }) });
      await store.put("leads:index", leads);
      const n = leads[c.clave].nombreCliente || leads[c.clave].nombre || "…" + c.clave.slice(-4);
      return { tipo: "cliente", respuesta: personal ? `👥 Listo: ${n} es personal. Ya no le contesto ni le escribo.` : `💼 Listo: ${n} es cliente.` };
    }
    case "apagar": case "prender": {
      const activo = o.accion === "prender";
      await store.put("agente:config", normalizarConfig({ ...cfg, activo }));
      if (!activo) { const ev = (await store.get("revivir:estado")) ?? {}; if (ev.activa) await store.put("revivir:estado", { ...ev, activa: false }); }
      return { tipo: "estado", respuesta: activo ? "▶️ Prendida: contesto solo a prospectos nuevos que tú no has tocado (modo seguro)." : "⏸️ Apagada: no le contesto a nadie ni reviso clientes. Los avisos y recordatorios te siguen llegando." };
    }
    case "citas": {
      const l = relojLocal(cfg, new Date(t0 + o.dia * DIA_MS)).fecha;
      const citas = ((await store.get("agenda:citas")) ?? []).filter((x) => x.estado === "apartada" && relojLocal(cfg, new Date(x.id)).fecha === l).sort((a, b) => a.id.localeCompare(b.id));
      return { tipo: "citas", respuesta: citas.length ? `📅 Citas ${o.dia ? "mañana" : "hoy"}:\n${citas.map((x) => `• ${cuandoTexto(Date.parse(x.id), ahora, tz).replace(/^(hoy|mañana) /, "")} — ${x.nombre || "Cliente"}${x.interes ? ` (${String(x.interes).replace(/^Honda /, "")})` : ""} · wa.me/${x.cliente}`).join("\n")}` : `No hay citas ${o.dia ? "mañana" : "hoy"}.` };
    }
    case "resumen": case "pendientes": {
      const index = (await store.get("inbox:index")) ?? {};
      const esperando = Object.entries(index).filter(([k, c]) => k.startsWith("wa:") && c.lastDir === "in" && t0 - Date.parse(c.lastAt) < 3 * DIA_MS && !leads[k]?.personal);
      const recs = (await recordatoriosPendientes(store)).filter((r) => relojLocal(cfg, new Date(r.at)).fecha === relojLocal(cfg, ahora).fecha);
      const calientes = Object.values(leads).filter((l) => l.calor === "caliente" && !l.personal && !l.postventa).length;
      return { tipo: "resumen", respuesta: `☀️ Tu día:\n• ${esperando.length} chat(s) esperando respuesta (últimos 3 días)\n• ${recs.length} recordatorio(s) hoy\n• ${calientes} cliente(s) calientes\n• Sofía: ${cfg.activo ? "prendida (modo seguro)" : "apagada"}${esperando.length ? `\n\nEsperando:\n${esperando.sort((a, b) => String(b[1].lastAt).localeCompare(String(a[1].lastAt))).slice(0, 8).map(([k, c]) => `• ${leads[k]?.nombreCliente || c.name || "…" + k.slice(-4)}: ${String(c.lastText ?? "").slice(0, 70)}`).join("\n")}` : ""}` };
    }
  }
  return { tipo: "no-entendi", respuesta: AYUDA_JARVIS };
}

/** Cada minuto: los recordatorios que ya tocan le llegan a Mario por WhatsApp. */
async function dispararRecordatorios(env, store, ahora) {
  const lista = (await store.get("jarvis:recordatorios")) ?? [];
  const tocan = lista.filter((r) => !r.hecho && !r.avisado && r.at <= ahora.getTime());
  if (!tocan.length || !env.WA_WEB?.estado?.().ok && !waReady(env)) return 0;
  const leads = (await store.get("leads:index")) ?? {};
  let n = 0;
  for (const r of tocan) {
    r.avisado = true; // se marca antes: si falla el envío no se repite cada minuto
    await store.put("jarvis:recordatorios", lista);
    const texto = `⏰ *Recordatorio:* ${r.texto}${r.clave ? `\n\n${fichaCorta(r.clave, leads[r.clave] ?? { nombre: r.nombre })}` : ""}\n\nCuando lo hagas: *sofia listo*`;
    if (await avisarAMario(env, store, texto, ahora)) n++;
  }
  return n;
}

/**
 * Cada mensaje nuevo de un cliente: si pide algo que solo Mario puede resolver (reembolso, valuación, factura, su crédito,
 * que le marquen, descuento, entrega, queja, cambio de cita), le llega un aviso a Mario. Aunque Sofía esté apagada.
 * Una vez por chat y tema cada 6 h; no si Mario está escribiendo en ese chat (contestó hace menos de 15 min).
 */
async function vigilarPeticion(env, store, e, ahora) {
  if (e.canal !== "wa" || !String(e.texto ?? "").trim() || ahora - new Date(e.at) > 30 * 60e3) return 0;
  const pide = peticionesDe(e.texto);
  if (!pide.length) return 0;
  const clave = `${e.canal}:${e.id}`;
  const l = ((await store.get("leads:index")) ?? {})[clave] ?? {};
  if (l.personal && l.tipoManual) return 0;
  if (e.prev?.lastManualAt && ahora - new Date(e.prev.lastManualAt) < 15 * 60e3) return 0;
  const nuevos = [];
  for (const p of pide) {
    const k = `aviso:pide:${p.id}:${clave}`;
    const antes = await store.get(k);
    if (antes && ahora - new Date(antes) < 6 * 3600e3) continue;
    await store.put(k, ahora.toISOString());
    nuevos.push(p);
  }
  if (!nuevos.length) return 0;
  await store.put(`aviso:pide:ultimo:${clave}`, ahora.toISOString()); // el aviso de postventa de Sofía ya no se duplica
  const texto = `🔔 *${nuevos.map((p) => p.titulo).join(" + ")}*\n«${String(e.texto).replace(/\s+/g, " ").slice(0, 300)}»\nEsto no lo puedo resolver yo: te toca a ti.\n\n${fichaCorta(clave, { nombre: e.nombre, ...l })}\n\nPara recordártelo: *sofia recuérdame marcarle a ${(l.nombreCliente || e.nombre || "este cliente").split(" ")[0]} en 1 hora*`;
  return (await avisarAMario(env, store, texto, ahora)) ? nuevos.length : 0;
}

/** WhatsApp al asesor con el contexto del cliente (ASESOR_WHATSAPP en Conexiones). Si Meta no lo deja, queda en errores. */
async function avisarAsesor(env, store, cfg, e, cita, ahora, lead = {}) {
  // Con WhatsApp vinculado (el celular del asesor) y sin otro número, el aviso le llega a su propio chat «Tú».
  const vinculado = env.WA_WEB?.estado?.();
  const numero = String(env.ASESOR_WHATSAPP || (vinculado?.ok ? vinculado.phone : "") || "").replace(/\D/g, "");
  if (!numero || !(vinculado?.ok || waReady(env))) return;
  const nombre = cita?.nombre || lead.nombreCliente || e.nombre || "Cliente";
  const interes = cita?.interes || lead.interes;
  const resumen = cita?.resumen || lead.resumen;
  const pago = lead.formaPago === "contado" ? "De contado"
    : lead.formaPago === "credito" ? `Crédito${lead.enganche ? ` · enganche ${pesos(lead.enganche)}` : lead.enganchePct ? ` · enganche ${lead.enganchePct}%` : ""}` : "";
  const ultima = ((await store.get(`inbox:c:${e.canal}:${e.id}`)) ?? []).slice(-8)
    .map((m) => `${m.dir === "in" ? nombre : cfg.asesor || "Mario"}: ${String(m.text ?? "").trim()}`)
    .filter((x) => !x.endsWith(": ")).join("\n").slice(-900);
  const corrida = lead.mensualidad ? `Mensualidad mencionada: ${pesos(lead.mensualidad)}${lead.plazo ? ` a ${lead.plazo} meses` : ""}` : "";
  const soloDuda = !cita && !lead.quiereAsesor && lead.duda;
  const siguiente = cita ? "Confirmar la visita y recibirlo en agencia" : soloDuda ? "Contestarle ese dato; Sofía sigue la plática mientras" : lead.quiereAsesor ? "Contactarlo y retomar la conversación" : "Dar seguimiento a la cotización";
  const renglones = [
    cita ? `📅 CITA · ${nombre} · ${cita.texto}` : soloDuda ? `❓ ${/auto a cuenta/i.test(lead.duda) ? "AUTO A CUENTA" : "TE PREGUNTA ALGO QUE NO SÉ"} · ${nombre}\n«${lead.duda}»` : lead.postventa ? `🛠️ POSTVENTA (devolución, servicio o trámite) · ${nombre} · Sofía le dijo que lo revisas y le confirmas; no le vende en este chat 12 h` : `🔥 PIDE ASESOR · ${nombre}`,
    interes && `Vehículo: ${interes}${lead.precio ? ` · ${pesos(lead.precio)}` : ""}`,
    pago,
    corrida,
    lead.autoAToma && `Auto a cuenta: ${lead.autoAToma}`,
    `Siguiente paso: ${siguiente}`,
    resumen && `Resumen: ${resumen}`,
    ultima && `Últimos mensajes:\n${ultima}`,
    e.canal === "wa" ? `Abrir chat: https://wa.me/${e.id}` : "Cliente de Messenger",
  ];
  const texto = renglones.filter(Boolean).join("\n");
  try {
    await sendMessage(env, store, { channel: "wa", to: numero.length === 10 ? `52${numero}` : numero, text: texto }, { ahora });
  } catch (err) {
    await anotarError(store, e, `Aviso a ${cfg.asesor || "el asesor"}: ${err.message ?? err} (Meta solo deja escribirle si él le mandó un mensaje al número de Sofía en las últimas 24 h)`, ahora);
  }
}

// Lo que el menú resuelve siempre él mismo, aun con IA: el freno contra bucles, el silencio mientras atiende el
// asesor, mensajes sin texto y los derechos del aviso de privacidad.
const SIN_IA = new Set(["freno", "con-asesor", "vacio", "borrar-datos", "sin-promociones", "comando-prueba-requerido"]);

/**
 * Sin IA, contesta el menú. Con IA, Sofía lleva toda la plática como vendedora (el menú queda de respaldo: si la IA
 * falla, va lo del menú y el error regresa en errorIA). historial: función que trae la conversación.
 */
async function pensarVenta(env, cfg, inventario, antes, msg, historial, ahora, libres = []) {
  const r = decidir({ cfg, inventario, conv: antes, msg: { ...msg, enHorario: enHorario(cfg, ahora) }, ahora, libres });
  // Las reglas son el cerebro (precisas, no inventan). La IA solo entra cuando las reglas no entendieron.
  if (SIN_IA.has(r.motivo) || r.motivo !== "no-entendi" || !cfg.ventas.ia || !motorIA(env)) return r;
  try {
    const h = await historial();
    return aplicarIA(r, await preguntarIA(env, promptIA({ cfg, inventario, historial: h, libres })), { inventario, antes, ahora, libres, cfg, historial: h });
  } catch (err) {
    return { ...r, errorIA: err.message ?? String(err) };
  }
}

/** Lo que falló al contestar solo queda en agente:errores (la app muestra el último). */
async function anotarError(store, e, error, ahora) {
  const errores = (await store.get("agente:errores")) ?? [];
  errores.unshift({ at: ahora.toISOString(), canal: e.canal, id: e.id, error });
  await store.put("agente:errores", errores.slice(0, 20));
}

export const MODELO_IA = "claude-opus-5-5";
const CON_RESPALDO = new Set(["claude-opus-5-5", "claude-sonnet-5-5", "claude-opus-5", "claude-fable-5-1"]);

/**
 * Una respuesta de Claude con salida estructurada (ESQUEMA_IA) y el mismo SDK que usa la app (vendor/).
 * Esfuerzo bajo: son mensajes cortos de WhatsApp. Sin reintentos y con tiempo límite, porque Meta espera
 * respuesta del webhook. Si Claude rechaza, se usa otro modelo automáticamente (fallbacks) cuando aplica.
 */
async function preguntarClaude(env, { system, messages }) {
  const sdk = await import("../vendor/anthropic-sdk.mjs");
  const cliente = new sdk.default({ apiKey: env.ANTHROPIC_API_KEY, maxRetries: 0, timeout: 15_000, ...(env.ANTHROPIC_BASE_URL ? { baseURL: env.ANTHROPIC_BASE_URL } : {}) });
  const model = env.ANTHROPIC_MODEL || MODELO_IA;
  const params = { model, max_tokens: 16000, system, messages, output_config: { effort: "low", format: sdk.jsonSchemaOutputFormat(ESQUEMA_IA) } };
  if (CON_RESPALDO.has(model)) Object.assign(params, { betas: ["server-side-fallback-2026-07-01"], fallbacks: "default" });
  const res = await cliente.beta.messages.create(params);
  if (res.stop_reason === "refusal") throw new Error("Claude no quiso contestar ese mensaje");
  if (res.stop_reason === "max_tokens") throw new Error("respuesta incompleta");
  return JSON.parse(res.content.filter((b) => b.type === "text").map((b) => b.text).join(""));
}

// IA GRATIS: Workers AI de Cloudflare (enlace "AI" en el Worker), con su cuota diaria sin costo. Se usa cuando no
// hay llave de Claude. Habla bien español aunque menos natural que Claude.
export const MODELO_GRATIS = "@cf/meta/llama-3.3-70b-instruct-fp8-fast";

/** El primer objeto JSON de un texto (los modelos abiertos a veces agregan algo antes o después). */
function leerJson(texto) {
  const t = String(texto ?? "");
  try { return JSON.parse(t); } catch { /* sigue */ }
  const a = t.indexOf("{");
  const b = t.lastIndexOf("}");
  if (a < 0 || b <= a) throw new Error("la IA no contestó en el formato esperado");
  return JSON.parse(t.slice(a, b + 1));
}

const formatoDe = (esquema) => `\n\nContesta SOLO con un objeto JSON con estas llaves: ${Object.entries(esquema.properties).map(([k, v]) => `${k} (${v.description})`).join("; ")}.`;

async function preguntarCloudflare(env, { system, messages }, { esquema = ESQUEMA_IA, max = 800, espera = 20_000 } = {}) {
  const ai = env.AI?.run ? env.AI : iaPorApi({ cuenta: env.CF_ACCOUNT_ID, llave: env.CF_API_TOKEN });
  if (!ai) throw new Error("Conecta Workers AI en Más → Conexiones.");
  const llamada = ai.run(env.CF_AI_MODEL || MODELO_GRATIS, {
    messages: [{ role: "system", content: system + formatoDe(esquema) }, ...messages],
    response_format: { type: "json_schema", json_schema: esquema },
    max_tokens: max,
    temperature: 0.7,
  });
  const res = await Promise.race([llamada, new Promise((_, no) => setTimeout(() => no(new Error("la IA de Cloudflare tardó demasiado")), espera))]);
  const r = res?.response ?? res;
  return r && typeof r === "object" ? r : leerJson(r);
}

// IA LOCAL en otro equipo (Ollama, LM Studio o cualquier servidor compatible con OpenAI), configurable desde ⚙:
// LOCAL_AI_URL (http://192.168.1.50:11434 o un túnel https), LOCAL_AI_MODEL (qwen2.5:3b) y LOCAL_AI_KEY opcional.
export const MODELO_LOCAL = "qwen2.5:3b";
async function preguntarLocal(env, { system, messages }, { esquema = ESQUEMA_IA, max = 600, espera = 45_000 } = {}) {
  const base = String(env.LOCAL_AI_URL ?? "").replace(/\/+$/, "").replace(/\/v1$/, "");
  const control = new AbortController();
  const limite = setTimeout(() => control.abort(), espera);
  try {
    const res = await fetch(`${base}/v1/chat/completions`, {
      method: "POST",
      signal: control.signal,
      headers: { "content-type": "application/json", ...(env.LOCAL_AI_KEY ? { authorization: `Bearer ${env.LOCAL_AI_KEY}` } : {}) },
      body: JSON.stringify({ model: env.LOCAL_AI_MODEL || MODELO_LOCAL, messages: [{ role: "system", content: system + formatoDe(esquema) }, ...messages], response_format: { type: "json_object" }, temperature: 0.5, max_tokens: max }),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error?.message || data.error || `la IA local respondió ${res.status}`);
    return leerJson(data.choices?.[0]?.message?.content);
  } catch (e) {
    throw new Error(e.name === "AbortError" ? "la IA local tardó demasiado" : `IA local: ${e.message ?? e}`);
  } finally { clearTimeout(limite); }
}

/**
 * Cada IA para lo suyo:
 *  - «chat» (contestarle a un cliente, rápido y bien escrito): Cloudflare 70B → IA local si se acabó la cuota → Claude.
 *  - «fondo» (ordenar y resumir chats, aprender de Mario; sin prisa y sin límite): IA local → Cloudflare.
 */
const motoresIA = (env, tarea = "chat") => {
  const cf = (env.AI?.run || iaPorApi({ cuenta: env.CF_ACCOUNT_ID, llave: env.CF_API_TOKEN })) && "cloudflare";
  const local = /^https?:\/\/\S+$/.test(String(env.LOCAL_AI_URL ?? "")) && "local";
  // Fondo: con IA local, SOLO la local. Si se cae, el fondo espera; no se come la cuota diaria de Cloudflare
  // (el 24-nov la gastó entera ordenando chats y Sofía se quedó sin IA para platicar).
  return (tarea === "fondo" ? (local ? [local] : [cf]) : [cf, local, env.ANTHROPIC_API_KEY && "claude"]).filter(Boolean);
};
const motorIA = (env) => motoresIA(env)[0] ?? null;

async function preguntarIA(env, prompt, { tarea = "chat", esquema, max } = {}) {
  if (!prompt.messages.length) throw new Error("sin mensajes del cliente");
  const motores = motoresIA(env, tarea);
  if (!motores.length) throw new Error("no hay IA conectada en el servidor");
  const errores = [];
  const opciones = { ...(esquema ? { esquema } : {}), ...(max ? { max } : {}), ...(tarea === "fondo" ? { espera: 120_000 } : {}) };
  for (const motor of motores) {
    try {
      if (motor === "cloudflare") return { ...(await preguntarCloudflare(env, prompt, opciones)), _motor: motor };
      if (motor === "local") return { ...(await preguntarLocal(env, prompt, opciones)), _motor: motor };
      if (motor === "claude" && !esquema) return await preguntarClaude(env, prompt);
    } catch (e) { errores.push(`${motor}: ${e.message ?? e}`); }
  }
  throw new Error(errores.join(" · "));
}

/** Lo que el cliente fue diciendo (auto, crédito, enganche, cita…) se guarda en su prospecto para la app. */
async function actualizarLead(store, e, cambios, ahora) {
  const leads = (await store.get("leads:index")) ?? {};
  const clave = `${e.canal}:${e.id}`;
  const l = Object.hasOwn(leads, clave) ? leads[clave] : { canal: e.canal, id: e.id, nombre: e.nombre || "", primerMensaje: String(e.texto ?? "").slice(0, 300), at: ahora.toISOString(), importado: false };
  if (l.calorManual && cambios.calor) cambios = { ...cambios, calor: undefined }; // Mario ya lo acomodó a mano
  Object.assign(l, cambios, { actualizado: ahora.toISOString() });
  if (l.calor === undefined) delete l.calor;
  // Pide cita o asesor: vuelve a "nuevos" aunque ya se hubiera agregado como cliente (la app lo avisa).
  if (cambios.cita || cambios.quiereAsesor) { l.importado = false; delete l.importadoAt; }
  leads[clave] = l;
  await store.put("leads:index", leads);
}

/** La app manda su inventario completo; las fotos que ya nadie usa se borran. */
async function guardarInventario(store, autos) {
  if (!Array.isArray(autos)) throw invalido("Falta el inventario (autos)");
  if (autos.length > MAX_AUTOS) throw invalido(`Máximo ${MAX_AUTOS} autos`);
  const txt = (x, max = 80) => String(x ?? "").trim().slice(0, max);
  const num = (x) => { const n = Number(String(x ?? "").replace(/[^\d.]/g, "")); return Number.isFinite(n) && n > 0 ? n : 0; };
  const limpio = autos.map((a) => {
    if (!a || typeof a !== "object") throw invalido("Auto inválido");
    const id = txt(a.id, 40);
    if (!/^[\w-]+$/.test(id)) throw invalido("Cada auto necesita un id");
    if (!txt(a.modelo) && !txt(a.marca)) throw invalido("Cada auto necesita marca o modelo");
    return {
      id, marca: txt(a.marca), modelo: txt(a.modelo), version: txt(a.version), anio: num(a.anio) || "",
      precio: num(a.precio), tipo: a.tipo === "seminuevo" ? "seminuevo" : "nuevo", km: num(a.km),
      color: txt(a.color), transmision: txt(a.transmision), descripcion: txt(a.descripcion, 400), promo: txt(a.promo, 200),
      palabras: (Array.isArray(a.palabras) ? a.palabras : String(a.palabras ?? "").split(",")).map((x) => txt(x, 40)).filter(Boolean).slice(0, 10),
      disponible: a.disponible !== false,
      ...(MEDIA_ID.test(a.fotoId ?? "") ? { fotoId: a.fotoId } : {}),
    };
  });
  const antes = (await store.get("ventas:inventario")) ?? [];
  const usadas = new Set(limpio.map((a) => a.fotoId).filter(Boolean));
  for (const a of antes) if (a.fotoId && !usadas.has(a.fotoId)) await borrar(store, `media:${a.fotoId}`);
  await store.put("ventas:inventario", limpio);
  return limpio;
}

const vistaAuto = (a, base) => ({ ...a, foto: a.fotoId ? `${base}/media/${a.fotoId}` : null });

// ───────── Prospectos ─────────
// leads:index → { "<canal>:<id>": { canal, id, nombre, primerMensaje, at, importado, importadoAt? } }
// Se crea con el PRIMER mensaje de un contacto que el conector no conocía; la app lo convierte en cliente
// y lo marca como importado (/api/prospectos/marcar).

const MAX_LEADS = 1000;

async function addLead(store, canal, id, nombre, msg) {
  const leads = (await store.get("leads:index")) ?? {};
  const clave = `${canal}:${id}`;
  if (leads[clave]) return;
  leads[clave] = { canal, id, nombre: nombre || "", primerMensaje: (msg.text || (msg.media ? `[${msg.type}]` : "")).slice(0, 300), at: msg.at, importado: false };
  const claves = Object.keys(leads);
  if (claves.length > MAX_LEADS) {
    // Si crece demasiado se olvidan primero los ya importados y, entre ellos, los más viejos.
    const orden = claves.sort((a, b) => Number(leads[b].importado) - Number(leads[a].importado) || leads[a].at.localeCompare(leads[b].at));
    for (const k of orden.slice(0, claves.length - MAX_LEADS)) delete leads[k];
  }
  await store.put("leads:index", leads);
}

/** Messenger no manda el nombre en el webhook: se pide una vez, en el primer contacto. */
async function nombreMessenger(env, store, psid) {
  if (!fbReady(env)) return "";
  const prev = ((await store.get("inbox:index")) ?? {})[`fb:${psid}`];
  if (prev) return prev.name ?? "";
  try {
    const p = await graph(env, `${encodeURIComponent(psid)}?fields=first_name,last_name`, { token: env.FB_PAGE_TOKEN });
    return [p.first_name, p.last_name].filter(Boolean).join(" ");
  } catch { return ""; } // sin permiso o perfil privado: se queda sin nombre
}

/** Fecha que manda Meta (en milisegundos); si viene vacía o mal, la hora de llegada (el webhook nunca debe tronar). */
function fechaMeta(ms, ahora) {
  const d = new Date(ms);
  return Number.isNaN(d.getTime()) ? ahora.toISOString() : d.toISOString();
}

const AVISO_MS = 10 * 60 * 1000; // webhook:last se reescribe como mucho cada 10 min

async function handleWebhook(req, env, store, ahora) {
  const raw = new Uint8Array(await req.arrayBuffer());
  if (!env.META_APP_SECRET) return fail("Falta META_APP_SECRET en el servidor", 500);
  const sig = (req.headers.get("x-hub-signature-256") ?? "").replace(/^sha256=/, "");
  if (!sameSecret(sig, await hmacHex(env.META_APP_SECRET, raw))) return fail("Firma inválida", 401);
  let body;
  try { body = JSON.parse(new TextDecoder().decode(raw)); } catch { return fail("JSON inválido"); }
  // Solo sirve para mostrar "último aviso de Meta": no se escribe en cada aviso (cuida el límite gratis de KV).
  const ultimo = await store.get("webhook:last");
  if (!ultimo || ultimo.object !== body.object || !(ahora - new Date(ultimo.at) < AVISO_MS)) await store.put("webhook:last", { at: ahora.toISOString(), object: body.object });

  return procesarEventos(body, env, store, ahora, baseDe(req));
}

export async function eventoVinculado(body, env, store) {
  const config = await conConexion(env, store);
  return procesarEventos(body, config, store, new Date(), config.PUBLIC_URL || "");
}

async function procesarEventos(body, env, store, ahora, base, { autoResponder = true } = {}) {
  const cfg = await leerConfig(store);
  const contestados = new Set(); // como mucho una respuesta automática por contacto en cada aviso de Meta
  // Cada mensaje entrante NUEVO: se guarda, se vuelve prospecto si es el primer contacto y, si toca, se contesta.
  // propio: lo mandó nuestro mismo número (no es prospecto ni se le contesta).
  const recibido = async (canal, peer, nombre, msg, { contestable, propio = false, pruebaLocal = false }) => {
    const r = await addMessage(store, canal, peer, nombre, msg);
    if (!r || propio) return; // reintento de Meta (ya se procesó) o mensaje de nuestro propio número
    if (!r.prev && !pruebaLocal) await addLead(store, canal, peer, nombre, msg);
    const clave = `${canal}:${peer}`;
    // Lo que el cliente pide y solo Mario resuelve: aviso a Mario (también con Sofía apagada; nunca al importar historial).
    if (autoResponder && !pruebaLocal) await vigilarPeticion(env, store, { canal, id: peer, nombre, texto: msg.text, at: msg.at, prev: r.prev }, ahora).catch((err) => console.warn("Vigilante:", err.message));
    if (!contestable || !autoResponder || contestados.has(clave)) return;
    try {
      const e = { canal, id: peer, nombre, texto: msg.text, at: msg.at, primero: !r.prev, prev: r.prev, pruebaLocal };
      if (await (cfg.ventas.activo ? responderVentas(env, store, cfg, e, ahora, base) : responderSolo(env, store, cfg, e, ahora))) contestados.add(clave);
    } catch (e) {
      console.error("Agente de Sofía:", e); // nunca romper el webhook: Meta reintentaría y se duplicaría el trabajo
    }
  };

  if (body.object === "whatsapp_business_account") {
    for (const entry of body.entry ?? []) for (const ch of entry.changes ?? []) {
      const v = ch.value ?? {};
      // Coexistencia: lo que el asesor escribe desde su WhatsApp Business, su historial y si se desconectó.
      if (ch.field === "smb_message_echoes") { for (const m of v.message_echoes ?? []) await ecoDelAsesor(store, m, ahora); continue; }
      if (ch.field === "history") { await historialCoexistencia(store, v, ahora); continue; }
      if (ch.field === "account_update") { await cambioCoexistencia(store, v, ahora); continue; }
      if (ch.field === "smb_app_state_sync") continue; // contactos del celular: no hacen falta
      const names = Object.fromEntries((v.contacts ?? []).map((c) => [c.wa_id, c.profile?.name ?? ""]));
      const propio = String(v.metadata?.display_phone_number ?? "").replace(/\D/g, "");
      for (const m of v.messages ?? []) {
        const media = ["image", "video", "document", "audio", "sticker"].includes(m.type) ? { id: m[m.type]?.id, mime: m[m.type]?.mime_type, filename: m[m.type]?.filename ?? "" } : undefined;
        // El origen de prueba solo es válido si el conector vinculado está en modo
        // «Solo mi WhatsApp». El webhook normal no puede reactivar a Sofía.
        const pruebaLocal = m.pruebaLocal === true && env.WA_WEB?.estado?.().modo === "solo-mi-whatsapp";
        await recibido("wa", m.from, names[m.from], { id: m.id, dir: "in", type: m.type, text: waText(m), at: fechaMeta(Number(m.timestamp) * 1000, ahora), ...(media ? { media } : {}) },
          { contestable: !SIN_RESPUESTA.has(m.type) && !m.errors, propio: !pruebaLocal && Boolean(propio) && m.from === propio, pruebaLocal });
      }
      for (const st of v.statuses ?? []) await setStatus(store, "wa", st.recipient_id, st.id, st.status);
    }
  } else if (body.object === "page") {
    for (const entry of body.entry ?? []) for (const ev of entry.messaging ?? []) {
      // El botón "Empezar" y los botones de la página llegan como postback: también son mensajes del cliente.
      const message = ev.message ?? (ev.postback ? { mid: ev.postback.mid ?? `pb.${ev.sender?.id}.${ev.timestamp}`, text: ev.postback.title ?? "" } : null);
      if (!message || message.is_echo) continue; // ecos de lo que manda la página: no son del cliente
      const psid = ev.sender?.id;
      if (!psid || psid === env.FB_PAGE_ID) continue;
      const att = message.attachments?.[0];
      await recibido("fb", psid, await nombreMessenger(env, store, psid), {
        id: message.mid, dir: "in", type: att ? att.type : "text", text: message.text ?? "", at: fechaMeta(ev.timestamp, ahora),
        ...(att?.payload?.url ? { media: { url: att.payload.url, mime: att.type === "image" ? "image/jpeg" : "" } } : {}),
      }, { contestable: true });
    }
  }
  return json({ ok: true });
}

// ───────── Coexistencia: el WhatsApp Business que el asesor ya usa en su celular, también por la API ─────────
// Se conecta con el registro integrado de Meta (Embedded Signup con featureType «whatsapp_business_app_onboarding»):
// el asesor sigue usando su app y sus chats; Sofía contesta desde el mismo número y se calla cuando él escribe.
// coex:estado    → { estado: "conectado"|"desconectado", numero, nombre, wabaId, phoneId, coexistencia, at, pasos, evento? }
// coex:historial → { mensajes, delAsesor, hilos: [ids], ejemplos: [textos del asesor], progreso, error?, at }

const CAMPOS_WEBHOOK = "messages,smb_message_echoes,history,smb_app_state_sync,account_update";
const MAX_EJEMPLOS_CHATS = 300;
const MAX_HILOS = 5000;

/** El asesor contestó desde su celular hace menos de horasConAsesor: la plática ya es suya. */
function contestaElAsesor(cfg, e, ahora) {
  const horas = cfg.ventas?.horasConAsesor ?? VENTAS_BASE.horasConAsesor;
  return Boolean(e.prev?.lastAppAt) && horas > 0 && ahora - new Date(e.prev.lastAppAt) < horas * 3600 * 1000;
}

/** La conversación que ya existe con ese número (en México el mismo cliente llega como 52… o 521…). */
async function peerWa(store, numero) {
  const n = String(numero ?? "").replace(/\D/g, "");
  const index = (await store.get("inbox:index")) ?? {};
  const otros = n.length === 13 && n.startsWith("521") ? [`52${n.slice(3)}`] : n.length === 12 && n.startsWith("52") ? [`521${n.slice(2)}`] : [];
  return [n, ...otros].find((x) => index[`wa:${x}`]) ?? n;
}

/** Mensaje que el asesor mandó desde su WhatsApp Business: se guarda en la plática y Sofía se calla ahí. */
async function ecoDelAsesor(store, m, ahora) {
  if (!m?.to || ["edit", "revoke", "reaction"].includes(m.type)) return;
  const at = fechaMeta(Number(m.timestamp) * 1000, ahora);
  await addMessage(store, "wa", await peerWa(store, m.to), "", { id: m.id, dir: "out", type: m.type, text: waText(m), at, desdeApp: true }, undefined, { lastAppAt: at });
}

/** Un mensaje del asesor sirve de ejemplo de cómo escribe si no trae datos de nadie (teléfonos, ligas, correos, cifras). */
function ejemploLimpio(texto) {
  const t = String(texto ?? "").replace(/\s+/g, " ").trim();
  if (t.length < 12 || t.length > 280) return null;
  if (/https?:\/\/|www\.|\S+@\S+\.\w|\d[\d\s-]{6,}\d|[A-Z]{4}\d{6}/i.test(t) || cifras(t).length) return null;
  return t;
}

/** n ejemplos repartidos (no solo los primeros), para que Sofía vea varias situaciones. */
const muestra = (lista, n) => (lista.length <= n ? lista : Array.from({ length: n }, (_, i) => lista[Math.floor((i * lista.length) / n)]));

/** Historial de hasta 6 meses que comparte el asesor al conectar: Sofía aprende cómo escribe él. */
async function historialCoexistencia(store, v, ahora) {
  const h = (await store.get("coex:historial")) ?? { mensajes: 0, delAsesor: 0, hilos: [], ejemplos: [], progreso: 0 };
  for (const parte of v.history ?? []) {
    if (parte.errors?.length) { h.error = parte.errors[0].message || parte.errors[0].title || "El historial no se compartió"; continue; }
    h.progreso = Math.max(h.progreso, Number(parte.metadata?.progress) || 0);
    for (const hilo of parte.threads ?? []) {
      if (hilo.id && h.hilos.length < MAX_HILOS && !h.hilos.includes(hilo.id)) h.hilos.push(hilo.id);
      for (const m of hilo.messages ?? []) {
        h.mensajes += 1;
        if (!m.from || m.from === hilo.id) continue; // lo escribió el cliente
        h.delAsesor += 1;
        const t = m.type === "text" ? ejemploLimpio(m.text?.body) : null;
        if (t && h.ejemplos.length < MAX_EJEMPLOS_CHATS && !h.ejemplos.includes(t)) h.ejemplos.push(t);
      }
    }
  }
  h.at = ahora.toISOString();
  await store.put("coex:historial", h);
  if (!h.ejemplos.length) return;
  const cfg = await leerConfig(store);
  await store.put("agente:config", normalizarConfig({ ...cfg, estilo: { ...cfg.estilo, deChats: muestra(h.ejemplos, 40) } }));
}

/** Meta avisa si el asesor quitó la conexión (o la volvió a poner) desde su app. */
async function cambioCoexistencia(store, v, ahora) {
  if (!["PARTNER_REMOVED", "ACCOUNT_OFFBOARDED", "ACCOUNT_RECONNECTED"].includes(v.event)) return;
  const c = (await store.get("coex:estado")) ?? {};
  await store.put("coex:estado", { ...c, estado: v.event === "ACCOUNT_RECONNECTED" ? "conectado" : "desconectado", evento: v.event, motivo: v.disconnection_info?.reason ?? "", eventoAt: ahora.toISOString() });
}

/**
 * Termina el registro integrado: cambia el código de Meta por la llave del negocio, ubica el número, suscribe la
 * cuenta y los campos del webhook, guarda todo en conexion:meta y pide el historial y los contactos (Meta da 24 h).
 * Nunca registra el número (/register): eso es para números nuevos en la API y aquí el número sigue en la app.
 */
async function conectarCoexistencia(envBase, store, base, body, ahora) {
  const env = await conConexion(envBase, store);
  const appId = env.META_APP_ID;
  const secreto = env.META_APP_SECRET;
  if (!appId) throw invalido("Falta el ID de la app de Meta");
  if (!secreto) throw invalido("Falta la clave secreta de la app de Meta");
  const code = String(body.code ?? "").trim();
  if (!/^[\w.#-]{10,2000}$/.test(code)) throw invalido("Falta el código que da Meta al terminar");
  const pide = (x) => (/^\d{1,25}$/.test(String(x ?? "")) ? String(x) : "");
  const llaveApp = `${appId}|${secreto}`;
  const pasos = [];
  const paso = async (nombre, fn) => {
    try { const r = await fn(); pasos.push({ paso: nombre, ok: true }); return r; } catch (e) { pasos.push({ paso: nombre, ok: false, error: e.message }); return null; }
  };

  const params = new URLSearchParams({ client_id: appId, client_secret: secreto, code });
  const { access_token: token } = await graph(env, `oauth/access_token?${params}`);
  if (!token) throw new Error("Meta no dio la llave del negocio");
  let wabaId = pide(body.waba_id);
  if (!wabaId) { // si el aviso de la ventana no llegó, la cuenta sale de los permisos de la llave
    const d = await graph(env, `debug_token?input_token=${encodeURIComponent(token)}`, { token: llaveApp });
    const ids = new Set((d.data?.granular_scopes ?? []).filter((x) => x.scope === "whatsapp_business_management").flatMap((x) => x.target_ids ?? []));
    if (ids.size === 1) wabaId = pide([...ids][0]);
  }
  if (!wabaId) throw new Error("Meta no dijo qué cuenta de WhatsApp se conectó");
  const numeros = (await graph(env, `${wabaId}/phone_numbers?fields=id,display_phone_number,verified_name,is_on_biz_app,platform_type`, { token })).data ?? [];
  const candidatos = numeros.filter((x) => x.is_on_biz_app === true && x.platform_type === "CLOUD_API" && (!body.phone_number_id || x.id === pide(body.phone_number_id)));
  if (candidatos.length !== 1) throw new Error("Meta debe identificar un único número que siga conectado a WhatsApp Business. Vuelve a seleccionar el número de Mario en el registro insertado.");
  const [tel] = candidatos;

  await guardarConexion(envBase, store, { WA_TOKEN: token, WA_PHONE_NUMBER_ID: tel.id, WA_WABA_ID: wabaId });
  const listo = await conConexion(envBase, store);
  await paso("Recibir los mensajes de esa cuenta", () => graph(env, `${wabaId}/subscribed_apps`, { method: "POST", token }));
  const callback = `${publicBase(listo, base)}/webhook/meta`;
  await paso("Avisos del webhook (mensajes, lo que escribe el asesor, historial)", () => {
    if (!callback.startsWith("https://")) throw new Error("El servidor no tiene dirección HTTPS");
    return graph(env, `${appId}/subscriptions`, { method: "POST", token: llaveApp, body: { object: "whatsapp_business_account", callback_url: callback, verify_token: listo.META_VERIFY_TOKEN, fields: CAMPOS_WEBHOOK } });
  });
  if (tel.is_on_biz_app) {
    await paso("Contactos del celular", () => graph(env, `${tel.id}/smb_app_data`, { method: "POST", token, body: { messaging_product: "whatsapp", sync_type: "smb_app_state_sync" } }));
    await paso("Historial de chats", () => graph(env, `${tel.id}/smb_app_data`, { method: "POST", token, body: { messaging_product: "whatsapp", sync_type: "history" } }));
  }
  const estado = { estado: "conectado", numero: tel.display_phone_number ?? "", nombre: tel.verified_name ?? "", wabaId, phoneId: tel.id, coexistencia: Boolean(tel.is_on_biz_app), at: ahora.toISOString(), pasos };
  await store.put("coex:estado", estado);
  return estado;
}

// ───────── Envíos ─────────

/**
 * b: { channel, to, text | template, image? (URL pública HTTPS: va con el texto como pie de foto) }.
 * autoKey: lo manda el agente (se guarda con auto: true). indice: datos para guardar junto a la conversación.
 */
async function sendMessage(env, store, b, { ahora = new Date(), autoKey, indice } = {}) {
  const at = ahora.toISOString();
  const auto = autoKey ? { auto: true } : {};
  if (b.channel === "fb") {
    if (!fbReady(env)) throw new Error("Facebook no está configurado en el servidor");
    const enviar = (message) => graph(env, `${env.FB_PAGE_ID}/messages`, { method: "POST", token: env.FB_PAGE_TOKEN, body: { recipient: { id: b.to }, messaging_type: "RESPONSE", message } });
    if (b.image) { // Messenger no lleva pie de foto: primero la foto y luego el texto
      const ri = await enviar({ attachment: { type: "image", payload: { url: b.image, is_reusable: true } } });
      await addMessage(store, "fb", b.to, "", { id: ri.message_id, dir: "out", type: "image", text: "", at, status: "sent", media: { url: b.image }, ...auto }, autoKey);
    }
    const r = await enviar({ text: b.text });
    await addMessage(store, "fb", b.to, "", { id: r.message_id, dir: "out", type: "text", text: b.text, at, status: "sent", ...auto }, autoKey, indice);
    return { id: r.message_id };
  }
  if (env.WA_WEB?.enviar) {
    if (b.template) throw new Error("Las plantillas de Meta requieren la API oficial.");
    let media;
    // La vendedora manda la foto como dirección pública (…/media/<id>); con WhatsApp vinculado se adjunta la
    // imagen guardada en vez de pegar el link en el texto.
    const imageId = b.imageId || String(b.image ?? "").match(/\/media\/([\w-]+)$/)?.[1];
    if (imageId) {
      const foto = MEDIA_ID.test(String(imageId)) ? await store.get(`media:${imageId}`) : null;
      if (!foto?.datos || !FOTOS.includes(foto.mime) || foto.datos.length > 7_000_000) {
        if (b.imageId) throw new Error("No encontré una foto válida del inventario.");
      } else media = { mime: foto.mime, datos: foto.datos };
    }
    const id = await env.WA_WEB.enviar({ ...b, ...(media || imageId ? { image: undefined } : {}), media });
    await addMessage(store, "wa", String(b.to), "", { id, dir: "out", type: media ? "image" : "text", text: b.text || "", at, status: "sent", ...(media ? { media: { mime: media.mime } } : {}), ...auto }, autoKey, indice);
    return { id };
  }
  if (!waReady(env)) throw new Error("WhatsApp no está configurado en el servidor");
  const to = String(b.to ?? "").replace(/\D/g, "");
  if (!to) throw new Error("Falta el número");
  let payload;
  let text = b.text ?? "";
  if (b.template) {
    const params = (b.template.params ?? []).map((t) => ({ type: "text", text: String(t) }));
    payload = { type: "template", template: { name: b.template.name, language: { code: b.template.lang || "es_MX" }, ...(params.length ? { components: [{ type: "body", parameters: params }] } : {}) } };
    text = b.template.preview || `[Plantilla ${b.template.name}]`;
  } else if (b.image && text.length <= MAX_PIE_WA) {
    payload = { type: "image", image: { link: b.image, ...(text ? { caption: text } : {}) } };
  } else {
    if (!text.trim()) throw new Error("Mensaje vacío");
    payload = { type: "text", text: { body: text, preview_url: true } };
  }
  const r = await graph(env, `${env.WA_PHONE_NUMBER_ID}/messages`, { method: "POST", token: env.WA_TOKEN, body: { messaging_product: "whatsapp", to, ...payload } });
  const id = r.messages?.[0]?.id;
  // Se guarda con el wa_id que confirma Meta: en México la app manda a 52 + 10 dígitos, pero el cliente
  // contesta (y llegan los estados) desde 521 + 10 dígitos. Así es una sola conversación y el agente
  // sabe que el asesor ya escribió (no hay bienvenida ni prospecto, y respeta pausaMinutos).
  const peer = String(r.contacts?.[0]?.wa_id ?? "").replace(/\D/g, "") || to;
  await addMessage(store, "wa", peer, "", { id, dir: "out", type: payload.type, text, at, status: "sent", ...(payload.image ? { media: { url: b.image } } : {}), ...auto }, autoKey, indice);
  return { id };
}
const MAX_PIE_WA = 1024; // WhatsApp: largo máximo del pie de foto

function deBase64(b64) {
  const bin = atob(b64);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return bytes;
}

function dataUrlToBlob(dataUrl) {
  const m = /^data:([^;]+);base64,(.*)$/s.exec(dataUrl ?? "");
  return m ? new Blob([deBase64(m[2])], { type: m[1] }) : null;
}

async function publishPost(env, store, b) {
  if (!fbReady(env)) throw new Error("Facebook no está configurado en el servidor");
  if (!b.message?.trim() && !b.image) throw new Error("La publicación está vacía");
  let r;
  const img = b.image ? dataUrlToBlob(b.image) : null;
  if (img) {
    const form = new FormData();
    form.append("caption", b.message ?? "");
    form.append("source", img, "foto.jpg");
    r = await graph(env, `${env.FB_PAGE_ID}/photos`, { method: "POST", token: env.FB_PAGE_TOKEN, form });
  } else {
    r = await graph(env, `${env.FB_PAGE_ID}/feed`, { method: "POST", token: env.FB_PAGE_TOKEN, body: { message: b.message, ...(b.link ? { link: b.link } : {}) } });
  }
  const postId = r.post_id ?? r.id;
  const posts = (await store.get("fb:posts")) ?? [];
  posts.unshift({ id: postId, at: new Date().toISOString(), message: (b.message ?? "").slice(0, 300), photo: Boolean(img) });
  await store.put("fb:posts", posts.slice(0, 200));
  return { id: postId, url: `https://www.facebook.com/${postId}` };
}

/** Instagram (cuenta profesional ligada a la página): primero un contenedor con la foto y luego se publica. */
async function publishInstagram(env, { caption, imageUrl }) {
  if (!igReady(env)) throw new Error("Instagram no está configurado en el servidor (falta IG_USER_ID)");
  const contenedor = await graph(env, `${env.IG_USER_ID}/media`, { method: "POST", token: env.FB_PAGE_TOKEN, body: { image_url: imageUrl, caption } });
  const r = await graph(env, `${env.IG_USER_ID}/media_publish`, { method: "POST", token: env.FB_PAGE_TOKEN, body: { creation_id: contenedor.id } });
  let url;
  try { url = (await graph(env, `${r.id}?fields=permalink`, { token: env.FB_PAGE_TOKEN })).permalink; } catch { /* ya se publicó; el enlace es opcional */ }
  return { id: r.id, ...(url ? { url } : {}) };
}

// ───────── Programador de publicaciones (Facebook e Instagram) ─────────
// social:cola  → [ { id, texto, mediaId?, mime?, cuando, canales, base, creado, estado, intentos, siguiente?, bloqueo?,
//                    resultados: { facebook?: { ok, id?, url?, error?, at }, instagram?: … } } ]
//                estado: "pendiente" → "publicando" → "publicado" | "error" (tras MAX_INTENTOS)
// media:<id>   → { mime, datos (base64) }  se sirve en público en /media/<id>: Instagram exige descargarla de una URL.
// social:hecho:<id>:<canal> → resultado ya publicado. En Cloudflare KV una copia vieja de la cola puede revivir
//                "pendiente" algo que ya salió; esta marca (clave propia, sin caché previa) evita publicarlo dos veces.

const CANALES = ["facebook", "instagram"];
const FOTOS = ["image/jpeg", "image/png", "image/gif"]; // nada de SVG: /media es público y comparte origen con la app
const MAX_INTENTOS = 3;
const MAX_COLA = 100;
const MAX_FOTO = 8 * 1024 * 1024; // límite de Instagram
const MAX_CAPTION_IG = 2200;
const REINTENTO_MS = 5 * 60 * 1000; // espera entre intentos: 5 min, luego 10 min
const BLOQUEO_MS = 15 * 60 * 1000; // si algo quedó "publicando" más tiempo, el proceso se cayó: se retoma

const nuevoId = () => crypto.randomUUID().replace(/-/g, "");
const hecho = (id, canal) => `social:hecho:${id}:${canal}`;
const MEDIA_ID = /^[a-f0-9]{32}$/;
// Archivos de WhatsApp que se entregan con su tipo; cualquier otro va como binario.
const MEDIA_SEGURA = /^(image\/(jpeg|png|gif|webp)|application\/pdf|audio\/(ogg|mpeg|mp4|aac|amr)|video\/(mp4|3gpp))$/;

/** Dirección pública del conector: PUBLIC_URL manda; si no, la de la petición (respetando el proxy HTTPS). */
function baseDe(req) {
  const u = new URL(req.url);
  const proto = (req.headers.get("x-forwarded-proto") ?? "").split(",")[0].trim();
  return `${proto ? `${proto}:` : u.protocol}//${u.host}`;
}
const publicBase = (env, base) => String(env.PUBLIC_URL || base || "").replace(/\/+$/, "");

async function programar(env, store, p, base, ahora) {
  if (!p || typeof p !== "object") throw invalido("Falta la publicación");
  const canales = [...new Set(Array.isArray(p.canales) ? p.canales : [])];
  if (!canales.length || canales.some((c) => !CANALES.includes(c))) throw invalido("Elige Facebook, Instagram o ambos");
  const texto = String(p.texto ?? "").trim();
  const cuando = new Date(p.cuando ?? ahora);
  if (Number.isNaN(cuando.getTime())) throw invalido("Fecha y hora inválidas");
  let foto = null;
  if (p.imagen) {
    const m = /^data:([\w/+.-]+);base64,([A-Za-z0-9+/=\s]+)$/.exec(String(p.imagen));
    if (!m || !FOTOS.includes(m[1])) throw invalido("La foto debe ser JPG, PNG o GIF");
    foto = { mime: m[1], datos: m[2].replace(/\s+/g, "") };
    if (foto.datos.length * 0.75 > MAX_FOTO) throw invalido("La foto pesa más de 8 MB");
  }
  if (!texto && !foto) throw invalido("La publicación está vacía");
  if (canales.includes("facebook") && !fbReady(env)) throw invalido("Facebook no está configurado en el servidor");
  if (canales.includes("instagram")) {
    if (!igReady(env)) throw invalido("Instagram no está configurado en el servidor (falta IG_USER_ID)");
    if (!foto) throw invalido("Instagram solo publica con foto");
    if (foto.mime !== "image/jpeg") throw invalido("Instagram solo acepta fotos JPG");
    if (texto.length > MAX_CAPTION_IG) throw invalido(`Instagram acepta máximo ${MAX_CAPTION_IG} caracteres`);
    // Meta descarga la foto desde internet: con http://192.168… (servidor en casa sin túnel) fallaría 3 veces en silencio.
    if (!publicBase(env, base).startsWith("https://")) throw invalido("Instagram descarga la foto de una dirección pública HTTPS: define PUBLIC_URL en el servidor (o usa el túnel/Cloudflare)");
  }
  const cola = (await store.get("social:cola")) ?? [];
  const terminadas = cola.filter((x) => x.estado === "publicado" || x.estado === "error");
  if (cola.length - terminadas.length >= MAX_COLA) throw invalido(`Ya hay ${MAX_COLA} publicaciones en espera`);
  const item = { id: nuevoId(), texto, cuando: cuando.toISOString(), canales, base, creado: ahora.toISOString(), estado: "pendiente", intentos: 0, resultados: {} };
  if (foto) {
    item.mediaId = nuevoId();
    item.mime = foto.mime;
    await store.put(`media:${item.mediaId}`, foto);
  }
  cola.push(item);
  // Historial acotado: se olvidan primero las terminadas más viejas (y su foto).
  const sobran = terminadas.sort((a, b) => a.cuando.localeCompare(b.cuando)).slice(0, Math.max(0, cola.length - MAX_COLA));
  for (const x of sobran) {
    if (x.mediaId) await borrar(store, `media:${x.mediaId}`);
    for (const c of x.canales) if (x.resultados?.[c]?.ok) await borrar(store, hecho(x.id, c));
  }
  await store.put("social:cola", cola.filter((x) => !sobran.includes(x)));
  return item;
}

/** Lo que ve la app: sin la foto (pesa), con su dirección pública. */
function vistaCola(env, x, base) {
  const v = { ...x, imagen: x.mediaId ? `${publicBase(env, base || x.base)}/media/${x.mediaId}` : null };
  delete v.base;
  delete v.bloqueo;
  return v;
}

async function publicarProgramada(env, store, x, base, ahora) {
  const foto = x.mediaId ? await store.get(`media:${x.mediaId}`) : null;
  for (const canal of x.canales) {
    if (x.resultados[canal]?.ok) continue; // ya salió en ese canal: no duplicar al reintentar el otro
    const previo = await store.get(hecho(x.id, canal));
    if (previo?.ok) { x.resultados[canal] = previo; continue; } // ya salió, aunque la cola diga otra cosa
    let r;
    try {
      if (x.mediaId && !foto) throw new Error("La foto ya no está en el servidor"); // nunca publicar solo el texto
      if (canal === "facebook") {
        r = await publishPost(env, store, { message: x.texto, ...(foto ? { image: `data:${foto.mime};base64,${foto.datos}` } : {}) });
      } else {
        if (!foto) throw new Error("Instagram solo publica con foto");
        if (!base) throw new Error("Falta PUBLIC_URL: Instagram necesita una dirección pública para descargar la foto");
        r = await publishInstagram(env, { caption: x.texto, imageUrl: `${base}/media/${x.mediaId}` });
      }
    } catch (e) {
      x.resultados[canal] = { ok: false, error: e.message ?? String(e), at: ahora.toISOString() };
      continue;
    }
    x.resultados[canal] = { ok: true, id: r.id, ...(r.url ? { url: r.url } : {}), at: ahora.toISOString() };
    await store.put(hecho(x.id, canal), x.resultados[canal]);
  }
  delete x.bloqueo;
  if (x.canales.every((c) => x.resultados[c]?.ok)) {
    x.estado = "publicado";
    delete x.siguiente;
  } else if (x.intentos >= MAX_INTENTOS) {
    x.estado = "error"; // no se reintenta en bucle: la app muestra el error de cada canal
  } else {
    x.estado = "pendiente";
    x.siguiente = new Date(ahora.getTime() + x.intentos * REINTENTO_MS).toISOString();
  }
}

/** Envía recordatorio por WhatsApp cerca de una hora antes, si la cita sigue activa. */
async function recordarCitas(env, store, ahora) {
  if (!(env.WA_WEB?.estado?.().ok || waReady(env))) return 0;
  if (env.WA_WEB?.estado?.().ok) await confirmarCitasDeManana(env, store, ahora);
  const citas = (await store.get("agenda:citas")) ?? [];
  const dentroDe = ahora.getTime() + 60 * 60 * 1000;
  const listas = citas.filter((c) => c.estado === "apartada" && c.canal === "wa" && !c.recordatorioEnviadoAt && !c.recordatorioBloqueado
    && (c.recordatorioIntentos ?? 0) < 3
    && (!c.recordatorioIntentoAt || ahora - new Date(c.recordatorioIntentoAt) >= 5 * 60 * 1000)
    && new Date(c.id) > ahora && new Date(c.id) <= dentroDe);
  let enviadas = 0;
  for (const cita of listas) {
    cita.recordatorioIntentoAt = ahora.toISOString();
    cita.recordatorioIntentos = (cita.recordatorioIntentos ?? 0) + 1;
    await store.put("agenda:citas", citas);
    const cfg = await leerConfig(store);
    const peer = (await store.get("inbox:index"))?.[`wa:${cita.cliente}`];
    if (!env.WA_WEB && (!peer?.lastInAt || ahora - new Date(peer.lastInAt) >= 24 * 60 * 60 * 1000)) {
      cita.recordatorioError = "Requiere una plantilla aprobada: la ventana de WhatsApp ya venció.";
      cita.recordatorioBloqueado = true;
      await store.put("agenda:citas", citas);
      continue;
    }
    const nombre = primerNombre(cita.nombre);
    const texto = `Hola${nombre ? ` ${nombre}` : ""}, ya casi: te espero hoy ${horaDeCita(cfg, cita.id)} en ${cfg.agencia || cfg.marca || "Honda"}. Al llegar pregunta por mí, ${cfg.asesor || "Mario Abarca"} 👋`;
    try {
      await sendMessage(env, store, { channel: "wa", to: cita.cliente, text: texto }, { ahora, autoKey: "cita:recordatorio" });
      cita.recordatorioEnviadoAt = ahora.toISOString();
      delete cita.recordatorioError;
      enviadas += 1;
    } catch (e) { cita.recordatorioError = e.message ?? String(e); }
    await store.put("agenda:citas", citas);
  }
  return enviadas;
}

// ───────── Trabajo solo (WhatsApp vinculado de Mario): confirmar citas, seguimiento y resumen del día ─────────

/** Día, fecha (AAAA-MM-DD) y minutos del día en la zona de la agencia. */
function relojLocal(cfg, fecha) {
  const p = Object.fromEntries(new Intl.DateTimeFormat("en-US", { timeZone: cfg.zonaHoraria, weekday: "short", year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", hourCycle: "h23" }).formatToParts(fecha).map((x) => [x.type, x.value]));
  return { dia: DIAS[p.weekday], fecha: `${p.year}-${p.month}-${p.day}`, min: Number(p.hour) * 60 + Number(p.minute) };
}
/** «a la 1 pm», «a las 11:30 am». */
function horaDeCita(cfg, iso) {
  const { min } = relojLocal(cfg, new Date(iso));
  const h24 = Math.floor(min / 60), h12 = h24 % 12 || 12, m = min % 60;
  return `${h12 === 1 ? "a la" : "a las"} ${h12}${m ? `:${String(m).padStart(2, "0")}` : ""} ${h24 < 12 ? "am" : "pm"}`;
}
/** Número de Mario (su chat «Tú» en el WhatsApp vinculado, u otro si se configuró ASESOR_WHATSAPP). */
function numeroDeMario(env) {
  const n = String(env.ASESOR_WHATSAPP || env.WA_WEB?.estado?.().phone || "").replace(/\D/g, "");
  return n.length === 10 ? `52${n}` : n;
}
/** ¿Es buena hora para escribirle a un cliente? Día de trabajo, de 10 am a 7 pm. */
function horaDeEscribir(cfg, ahora) {
  const l = relojLocal(cfg, ahora);
  return cfg.horario.dias.includes(l.dia) && l.min >= 10 * 60 && l.min < 19 * 60;
}
const conArticulo = (interes) => {
  const m = String(interes ?? "").replace(/^honda\s+/i, "").replace(/\s+(19|20)\d{2}$/, "").trim();
  if (!m) return { de: "tu próximo Honda", lo: "lo" };
  const fem = /^(hr-?v|br-?v|cr-?v|pilot|odyssey)\b/i.test(m);
  return { de: `${fem ? "la" : "el"} ${m}`, lo: fem ? "la" : "lo" };
};

/** Un día antes (de 10 am a 8 pm): «¿sigue en pie tu cita de mañana a la 1 pm?». Solo citas apartadas con anticipación. */
async function confirmarCitasDeManana(env, store, ahora) {
  const cfg = await leerConfig(store);
  const l = relojLocal(cfg, ahora);
  if (l.min < 10 * 60 || l.min >= 20 * 60) return 0;
  const manana = relojLocal(cfg, new Date(ahora.getTime() + 24 * 3600e3)).fecha;
  const citas = (await store.get("agenda:citas")) ?? [];
  const cita = citas.find((c) => c.estado === "apartada" && c.canal === "wa" && !c.confirmacionAt && relojLocal(cfg, new Date(c.id)).fecha === manana
    && ahora - new Date(c.creada ?? 0) > 3 * 3600e3);
  if (!cita) return 0;
  cita.confirmacionAt = ahora.toISOString(); // se marca antes: nunca dos veces aunque falle el envío
  await store.put("agenda:citas", citas);
  const nombre = primerNombre(cita.nombre);
  const { de } = conArticulo(cita.interes);
  const texto = `¡Hola${nombre ? ` ${nombre}` : ""}! Te escribo para confirmar tu cita de mañana ${horaDeCita(cfg, cita.id)}${cita.interes ? ` para que veas ${de}` : ""}. ¿Sigue en pie? 🙌`;
  try { await sendMessage(env, store, { channel: "wa", to: cita.cliente, text: texto }, { ahora, autoKey: "cita:confirmar" }); return 1; }
  catch (e) { await anotarError(store, { canal: "wa", id: cita.cliente }, `Confirmación de cita: ${e.message ?? e}`, ahora); return 0; }
}

/**
 * Seguimiento: a quien preguntó por un auto y dejó de contestar, Sofía le escribe como Mario al día siguiente y,
 * si sigue callado, a los 3 días; luego ya no. Nunca a postventa, a quien pidió no recibir promociones o borrar
 * sus datos, a quien tiene cita, ni a chats que Mario lleva a mano. Uno por minuto y máximo 25 al día.
 */
async function darSeguimiento(env, store, cfg, ahora) {
  if (cfg.ventas.seguimiento === false || !cfg.activo || !cfg.ventas.activo || !horaDeEscribir(cfg, ahora)) return 0;
  const hoy = relojLocal(cfg, ahora).fecha;
  const conteo = (await store.get("seguimiento:conteo")) ?? {};
  if ((conteo[hoy] ?? 0) >= 25) return 0;
  const leads = (await store.get("leads:index")) ?? {};
  const index = (await store.get("inbox:index")) ?? {};
  const DIA = 24 * 3600e3;
  // Con cita por venir o que ya vino esta semana: eso lo lleva Mario en persona.
  const conCita = new Set(((await store.get("agenda:citas")) ?? []).filter((c) => c.estado !== "cancelada" && new Date(c.id) > ahora - 7 * DIA).map((c) => `${c.canal || "wa"}:${c.cliente}`));
  const toca = Object.entries(leads).find(([clave, l]) => {
    const conv = index[clave];
    const etapa = l.seguimientos ?? 0;
    if (!clave.startsWith("wa:") || !conv || etapa >= 2 || l.postventa || l.noPromociones || l.pideBorrar || l.quiereAsesor) return false;
    if (["cerrado", "perdido"].includes(l.calor) || !(l.interes || ["tibio", "caliente"].includes(l.calor)) || conCita.has(clave)) return false;
    if (conv.lastDir !== "out" || !conv.lastInAt || ahora - new Date(conv.lastInAt) > 14 * DIA) return false; // ya contestó, o es muy viejo (eso es «revivir cartera»)
    if (conv.lastManualAt && new Date(conv.lastManualAt) >= new Date(conv.lastInAt)) return false; // Mario le contestó a mano: él lo lleva
    if (conv.venta?.silencioHasta && new Date(conv.venta.silencioHasta) > ahora) return false;
    if (etapa === 0) return ahora - new Date(conv.lastAt) >= 20 * 3600e3;
    return ahora - new Date(l.seguimientoAt ?? 0) >= 3 * DIA && new Date(conv.lastAt) <= new Date(new Date(l.seguimientoAt).getTime() + 60e3);
  });
  if (!toca) return 0;
  const [clave, l] = toca;
  const etapa = (l.seguimientos ?? 0) + 1;
  leads[clave] = { ...l, seguimientos: etapa, seguimientoAt: ahora.toISOString() }; // se marca antes de enviar
  await store.put("leads:index", leads);
  await store.put("seguimiento:conteo", Object.fromEntries([...Object.entries(conteo).filter(([f]) => f >= relojLocal(cfg, new Date(ahora.getTime() - 7 * DIA)).fecha), [hoy, (conteo[hoy] ?? 0) + 1]]));
  const nombre = primerNombre(l.nombreCliente || l.nombre || index[clave]?.name);
  const hola = `Hola${nombre ? ` ${nombre}` : ""}`;
  const { de, lo } = conArticulo(l.interes);
  const opciones = etapa === 1
    ? [`¡${hola}! ¿Pudiste ver lo de ${de}? Si quieres te armo la corrida o te aparto un horario para que ${lo} manejes, sin compromiso.`,
      `${hola}, ¿cómo vas? Me quedé pendiente de ${de}. ¿Te paso la corrida o prefieres venir a ver${lo}?`]
    : [`${hola}, no te quiero molestar 🙂 Sigo a tus órdenes con ${de}; esta semana te puedo armar algo a tu medida. Si ya no te interesa, dímelo y no te escribo más.`];
  const texto = opciones[huella(clave).charCodeAt(0) % opciones.length];
  try { await sendMessage(env, store, { channel: "wa", to: l.id, text: texto }, { ahora, autoKey: `seguimiento:${etapa}` }); return 1; }
  catch (e) { await anotarError(store, { canal: "wa", id: l.id }, `Seguimiento: ${e.message ?? e}`, ahora); return 0; }
}

/** A las 9 am (días de trabajo), un resumen a Mario en su chat «Tú»: citas de hoy, quién espera respuesta y los calientes. */
async function resumenDelDia(env, store, cfg, ahora, ahoraMismo = false) {
  const l = relojLocal(cfg, ahora);
  if (!ahoraMismo) {
    if (cfg.ventas.resumenDiario === false || !cfg.horario.dias.includes(l.dia) || l.min < 9 * 60 || l.min >= 12 * 60) return false;
    if ((await store.get("resumen:enviado")) === l.fecha) return false;
  }
  const mario = numeroDeMario(env);
  if (!mario) return false;
  if (!ahoraMismo) await store.put("resumen:enviado", l.fecha);
  const DIA = 24 * 3600e3;
  const leads = (await store.get("leads:index")) ?? {};
  const index = (await store.get("inbox:index")) ?? {};
  const nombreDe = (clave) => { const x = leads[clave] ?? {}; return x.nombreCliente || x.nombre || index[clave]?.name || `…${clave.slice(-4)}`; };
  const citas = ((await store.get("agenda:citas")) ?? []).filter((c) => c.estado === "apartada" && relojLocal(cfg, new Date(c.id)).fecha === l.fecha).sort((a, b) => a.id.localeCompare(b.id));
  const esperan = Object.entries(index).filter(([k, c]) => leads[k] && !leads[k].postventa && c.lastDir === "in" && ahora - new Date(c.lastAt) < 7 * DIA).map(([k]) => k);
  const calientes = Object.entries(leads).filter(([k, x]) => x.calor === "caliente" && ahora - new Date(x.actualizado ?? x.at ?? 0) < 14 * DIA).map(([k]) => k);
  const postventa = Object.entries(leads).filter(([k, x]) => x.postventa && index[k]?.lastDir === "in" && ahora - new Date(index[k].lastAt) < 3 * DIA).map(([k]) => k);
  const ayer = relojLocal(cfg, new Date(ahora.getTime() - DIA)).fecha;
  const seguidos = ((await store.get("seguimiento:conteo")) ?? {})[ayer] ?? 0;
  const nombres = (claves) => claves.slice(0, 6).map(nombreDe).join(", ") + (claves.length > 6 ? ` y ${claves.length - 6} más` : "");
  const texto = [
    `☀️ Buenos días, ${primerNombre(cfg.asesor) || "Mario"}. Así va tu día:`,
    citas.length ? `📅 Citas hoy (${citas.length}):\n${citas.map((c) => `• ${horaDeCita(cfg, c.id).replace(/^a las? /, "")} · ${c.nombre || nombreDe(`wa:${c.cliente}`)}${c.interes ? ` (${c.interes.replace(/^Honda\s+/i, "")})` : ""}`).join("\n")}` : "📅 Hoy no hay citas agendadas.",
    esperan.length ? `💬 Esperan respuesta (${esperan.length}): ${nombres(esperan)}` : "",
    postventa.length ? `🛠️ Postventa por atender (${postventa.length}): ${nombres(postventa)}` : "",
    calientes.length ? `🔥 Calientes (${calientes.length}): ${nombres(calientes)}` : "",
    seguidos ? `🔁 Ayer le di seguimiento a ${seguidos} cliente${seguidos === 1 ? "" : "s"} que se habían quedado callados.` : "",
    "Todo lo ves en Sofía Web.",
  ].filter(Boolean).join("\n\n");
  try { await sendMessage(env, store, { channel: "wa", to: mario, text: texto }, { ahora }); return true; }
  catch (e) { await anotarError(store, { canal: "wa", id: "resumen" }, `Resumen del día: ${e.message ?? e}`, ahora); return false; }
}

/** Lo que Sofía hace sola cada minuto con el WhatsApp de Mario (no en Cloudflare ni con la API de Meta). */
// ───────── Trabajo de fondo con IA: ordena y resume TODOS los chats solos, y aprende de cómo contesta Mario ─────────
// Lo hace de preferencia la IA local (sin límite); si no hay, Cloudflare con un tope diario para no gastarle la
// cuota a las pláticas con clientes. Nunca le escribe a nadie: solo llena la ficha de cada contacto.
const ESQUEMA_FONDO = {
  type: "object",
  properties: {
    tipo: { type: "string", description: "cliente (quiere comprar o cotizar un auto), postventa (ya compró: trámite, entrega, placas, devolución, servicio), personal (amigo, familia, compañero de trabajo) u otro (proveedor, publicidad, no se sabe)" },
    nombre: { type: "string", description: "nombre del contacto si lo dijo o se lo dijeron en el chat; vacío si no" },
    modelo: { type: "string", description: "auto que le interesa (ej. CR-V, City); vacío si no" },
    forma_pago: { type: "string", description: "contado, credito o vacío" },
    calor: { type: "string", description: "frio, tibio o caliente: qué tan cerca está de comprar" },
    resumen: { type: "string", description: "1 o 2 frases para Mario: qué busca y en qué quedó la plática" },
    siguiente: { type: "string", description: "lo que Mario debe hacer ahora, en una frase corta; vacío si nada" },
  },
  required: ["tipo", "nombre", "modelo", "forma_pago", "calor", "resumen", "siguiente"],
  additionalProperties: false,
};
const FONDO_TOPE_CLOUDFLARE = 40; // por día si no hay IA local
let fondoOcupado = false;

/** Pares reales «cliente → Mario» (Mario escribió a mano justo después del cliente): así aprende su forma de contestar. */
function paresDeMario(msgs) {
  const pares = [];
  for (let i = 1; i < msgs.length; i++) {
    const m = msgs[i], antes = msgs[i - 1];
    if (m.dir === "out" && !m.auto && antes.dir === "in" && String(m.text ?? "").trim().length >= 8 && String(antes.text ?? "").trim()) {
      pares.push(`Cliente: ${String(antes.text).replace(/\s+/g, " ").slice(0, 140)} → Mario: ${String(m.text).replace(/\s+/g, " ").slice(0, 220)}`);
    }
  }
  return pares;
}

/**
 * La IA chica se equivoca mucho con el tipo (el 23-nov marcó 0 clientes de 118 chats). Las reglas mandan:
 * - el chat empezó con el anuncio («Quiero más información») → cliente, nunca personal ni «otro»;
 * - postventa solo si en el chat hay un trámite (devolución, placas, factura, entrega…).
 */
export function tipoConReglas(tipo, msgs) {
  const sa = (s) => String(s ?? "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase();
  const todo = sa(msgs.map((m) => m.text).join(" "));
  const anuncio = msgs.some((m) => m.dir === "in" && /quiero mas informacion/.test(sa(m.text)));
  if (tipo === "postventa" && !TRAMITE_EN_CHAT.test(todo)) return anuncio || VENTA_EN_CHAT.test(todo) ? "cliente" : "otro";
  if (anuncio && (tipo === "personal" || tipo === "otro")) return "cliente";
  return tipo;
}

/** Arregla una sola vez las fichas que la IA de fondo ya había llenado antes de estas reglas. */
async function corregirTiposViejos(store) {
  if ((await store.get("fondo:tiposV1")) === true) return 0;
  const todos = (await store.get("leads:index")) ?? {};
  let n = 0;
  for (const [clave, l] of Object.entries(todos)) {
    if (l.tipoManual || !l.fondoMotor || l.fondoMotor === "mario") continue;
    const msgs = ((await store.get(`inbox:c:${clave}`)) ?? []).filter((m) => String(m.text ?? "").trim());
    const nuevo = tipoConReglas(l.tipo, msgs);
    if (nuevo === l.tipo) continue;
    l.tipo = nuevo; l.personal = nuevo === "personal"; l.postventa = nuevo === "postventa"; n++;
  }
  await store.put("leads:index", todos);
  await store.put("fondo:tiposV1", true);
  if (n) console.log(`Fondo: ${n} fichas corregidas con las reglas (la IA chica las había clasificado mal).`);
  return n;
}

/** Lee un chat con la IA de fondo y llena su ficha (tipo, nombre, modelo, pago, calor, resumen). Devuelve { l, r }. */
async function revisarChat(env, store, cfg, clave, c) {
  const msgs = ((await store.get(`inbox:c:${clave}`)) ?? []).filter((m) => String(m.text ?? "").trim());
  const ultimos = msgs.slice(-24);
  const quien = (m) => (m.dir === "in" ? "Contacto" : m.auto ? "Sofía (asistente de Mario)" : "Mario");
  const charla = ultimos.map((m) => `${quien(m)}: ${String(m.text).replace(/\s+/g, " ").slice(0, 300)}`).join("\n").slice(-5000);
  let r = null;
  if (charla) {
    r = await preguntarIA(env, {
      system: `Eres el asistente de ${cfg.asesor || "Mario Abarca"}, asesor de ventas de ${cfg.marca || "Honda"} en Monterrey. Lees un chat de su WhatsApp y llenas la ficha del contacto. Sé preciso: si no está en el chat, déjalo vacío. No inventes nombres, modelos ni cifras.`,
      messages: [{ role: "user", content: `Contacto en la agenda: ${c.name || "(sin nombre)"}\n\nChat:\n${charla}` }],
    }, { tarea: "fondo", esquema: ESQUEMA_FONDO, max: 400 }).catch((e) => { console.warn(`Fondo (${clave.slice(-4)}): ${e.message}`); return null; });
  }
  const todos = (await store.get("leads:index")) ?? {};
  const l = todos[clave] ?? { canal: "wa", id: clave.slice(3), nombre: c.name || "", primerMensaje: String(msgs.find((m) => m.dir === "in")?.text ?? "").slice(0, 300), at: c.lastAt, importado: false };
  l.fondoAt = c.lastAt;
  if (r) {
    const tipo = l.tipoManual ? l.tipo : tipoConReglas(["cliente", "postventa", "personal", "otro"].includes(r.tipo) ? r.tipo : "otro", msgs);
    if (!l.tipoManual) {
      l.tipo = tipo;
      l.personal = tipo === "personal";
      if (tipo === "postventa") l.postventa = true;
      l.fondoMotor = r._motor;
    }
    if (r.resumen?.trim()) l.resumen = r.resumen.trim().slice(0, 400);
    if (r.siguiente?.trim()) l.siguiente = r.siguiente.trim().slice(0, 160); else delete l.siguiente;
    if (r.nombre?.trim() && !l.nombreCliente && r.nombre.trim().length <= 40) l.nombreCliente = r.nombre.trim();
    if (r.modelo?.trim() && !l.interes) l.interes = `${cfg.marca || "Honda"} ${r.modelo.trim().slice(0, 40)}`.replace(/^(\w+) \1 /i, "$1 ");
    if (["contado", "credito"].includes(r.forma_pago) && !l.formaPago) l.formaPago = r.forma_pago;
    if (["frio", "tibio", "caliente"].includes(r.calor) && !l.calorManual && tipo === "cliente") l.calor = r.calor;
  }
  todos[clave] = l;
  await store.put("leads:index", todos);
  // Aprende: lo que Mario contestó a mano en este chat se suma a sus ejemplos (los más nuevos primero).
  const pares = paresDeMario(msgs.slice(-60));
  if (pares.length && !l.personal) {
    const cfgActual = await leerConfig(store);
    const deChats = [...new Set([...pares.reverse(), ...(cfgActual.estilo?.deChats ?? [])])].slice(0, 40);
    await store.put("agente:config", normalizarConfig({ ...cfgActual, estilo: { ...cfgActual.estilo, deChats } }));
  }
  return { l, r, msgs };
}

export async function trabajoDeFondo(env, store, ahora = new Date(), { max = 1 } = {}) {
  if (fondoOcupado) return { revisados: 0 };
  await corregirTiposViejos(store);
  const cfg = await leerConfig(store);
  const motores = motoresIA(env, "fondo");
  if (!cfg.ventas.ia || !motores.length) return { revisados: 0 };
  const dia = ahora.toISOString().slice(0, 10);
  const conteo = (await store.get("fondo:conteo")) ?? {};
  const usados = conteo.dia === dia ? conteo.n : 0;
  if (motores[0] === "cloudflare" && usados >= FONDO_TOPE_CLOUDFLARE) return { revisados: 0 };
  const index = (await store.get("inbox:index")) ?? {};
  const leads = (await store.get("leads:index")) ?? {};
  const limite = ahora.getTime() - 30 * 864e5;
  // Los chats con novedades desde la última revisión, los más recientes primero.
  const tocan = Object.entries(index)
    .filter(([k, c]) => k.startsWith("wa:") && Date.parse(c.lastAt) >= limite && (!leads[k]?.fondoAt || leads[k].fondoAt < c.lastAt))
    .sort((a, b) => String(b[1].lastAt).localeCompare(String(a[1].lastAt)))
    .slice(0, motores[0] === "local" ? Math.max(max, 3) : max); // la local no tiene cuota: 3 por minuto
  if (!tocan.length) return { revisados: 0 };
  fondoOcupado = true;
  let revisados = 0;
  try {
    for (const [clave, c] of tocan) {
      const { r } = await revisarChat(env, store, cfg, clave, c);
      if (r) revisados++;
    }
  } finally { fondoOcupado = false; }
  if (revisados) await store.put("fondo:conteo", { dia, n: usados + revisados });
  return { revisados };
}

// ───────── Etiquetas de WhatsApp Business por mes, modelo y estado ─────────
const MESES_ES = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"];
// Cómo pueden llamarse en el WhatsApp de Mario (sin acentos ni guiones): así se reconocen las que ya tiene.
export const ALIAS_ETIQUETAS = {
  "no leido": ["no leidos", "sin leer", "nuevo mensaje", "mensajes nuevos"],
  "cr v": ["crv"], "hr v": ["hrv"], "br v": ["brv"],
  "postventa": ["post venta", "servicio", "tramite"], "caliente": ["interes caliente", "prioridad"], "cita": ["cita agendada", "visita"],
  ...Object.fromEntries(MESES_ES.map((m) => [m.toLowerCase(), [m.slice(0, 3).toLowerCase(), `${m.toLowerCase()} 2026`, `leads ${m.toLowerCase()}`, `clientes ${m.toLowerCase()}`]])),
};

/** [{ to, etiquetas }] para cada chat que no es personal. El mes es el de su primer mensaje (hora de Monterrey). */
export async function planDeEtiquetas(store, cfg, ahora = new Date()) {
  const [leads, index, citas] = await Promise.all([store.get("leads:index"), store.get("inbox:index"), store.get("agenda:citas")]);
  const conCita = new Set((citas ?? []).filter((x) => x.estado !== "cancelada" && Date.parse(x.id) > ahora.getTime() - 864e5).map((x) => `${x.canal || "wa"}:${x.cliente}`));
  const mesDe = (iso) => { const n = Number(new Intl.DateTimeFormat("en-US", { timeZone: cfg.zonaHoraria || "America/Monterrey", month: "numeric" }).format(new Date(iso))); return MESES_ES[n - 1]; };
  const plan = [];
  for (const [clave, c] of Object.entries(index ?? {})) {
    if (!clave.startsWith("wa:")) continue;
    const l = leads?.[clave] ?? {};
    if (l.personal || l.tipo === "personal" || l.tipo === "otro") continue;
    const msgs = (await store.get(`inbox:c:${clave}`)) ?? [];
    const primero = [l.at, msgs[0]?.at].filter(Boolean).sort()[0];
    const modelo = modeloEn(l.interes || "") || modeloEn(msgs.filter((m) => m.dir === "in").map((m) => m.text).join(" "));
    const etiquetas = [
      primero && mesDe(primero),
      modelo,
      (l.postventa || l.tipo === "postventa") && "Postventa",
      !l.postventa && l.calor === "caliente" && "Caliente",
      conCita.has(clave) && "Cita",
    ].filter(Boolean);
    if (etiquetas.length) plan.push({ to: clave.slice(3), etiquetas });
  }
  return plan;
}

// ───────── Difusión: Mario arma en la app a quién y qué; el servidor manda uno por uno, aunque la app esté cerrada ─────────
// difusion:actual    → { id, mensaje, filtros, pendientes:[{clave,id,nombre,modelo}], enviados:[claves], fallidos:[claves], estado, creada, dia, hoy }
// difusion:recientes → { clave: fecha } (a quien ya le llegó una difusión hace menos de 3 días no se le repite)
// difusion:historial → [ { id, mensaje, total, enviados, fallidos, creada, terminada } ]
const DIFUSION_TOPE_DIA = 200; // por número y por día: protege el WhatsApp de Mario
const DIFUSION_POR_MINUTO = 3;
const DIFUSION_MAX = 500;
let difundiendo = false;

/** A quiénes les llegaría la difusión con esos filtros (sin amigos, postventa ni quien pidió que no le escriban). */
export async function audienciaDifusion(store, cfg, filtros = {}, ahora = new Date(), { propio = "" } = {}) {
  const [leads, index, recientes] = await Promise.all([store.get("leads:index"), store.get("inbox:index"), store.get("difusion:recientes")]);
  const tz = cfg.zonaHoraria || "America/Monterrey";
  const mesDe = (iso) => Number(new Intl.DateTimeFormat("en-US", { timeZone: tz, month: "numeric" }).format(new Date(iso)));
  const dias = (iso) => (ahora - new Date(iso)) / DIA_MS;
  const out = [];
  for (const [clave, c] of Object.entries(index ?? {})) {
    if (!clave.startsWith("wa:") || clave.endsWith(":0") || (propio && clave.endsWith(propio.slice(-10)))) continue;
    const l = leads?.[clave] ?? {};
    if (l.personal || l.tipo === "personal" || l.tipo === "otro" || l.noPromociones || l.pideBorrar || ["cerrado", "perdido"].includes(l.calor)) continue;
    if (!filtros.postventa && (l.postventa || l.tipo === "postventa")) continue;
    if (recientes?.[clave] && dias(recientes[clave]) < 3) continue;
    const msgs = filtros.mes || filtros.modelo ? (await store.get(`inbox:c:${clave}`)) ?? [] : [];
    const primero = [l.at, msgs[0]?.at, c.lastAt].filter(Boolean).sort()[0];
    if (filtros.mes && (!primero || mesDe(primero) !== Number(filtros.mes))) continue;
    const modelo = modeloEn(l.interes || "") || (msgs.length ? modeloEn(msgs.filter((m) => m.dir === "in").map((m) => m.text).join(" ")) : null);
    if (filtros.modelo && modelo !== filtros.modelo) continue;
    const calor = l.calor || "frio";
    if (filtros.calor && calor !== filtros.calor) continue;
    if (filtros.situacion === "no-contestaron" && !(c.lastDir === "out" && dias(c.lastAt) > 2)) continue;
    if (filtros.situacion === "esperan" && c.lastDir !== "in") continue;
    if (Number(filtros.diasSinHablar) > 0 && dias(c.lastAt) < Number(filtros.diasSinHablar)) continue;
    out.push({ clave, id: clave.slice(3), nombre: l.nombreCliente || c.name || l.nombre || "", modelo, calor, mes: primero ? mesDe(primero) : null, ultimo: c.lastAt });
  }
  return out.sort((a, b) => String(b.ultimo).localeCompare(String(a.ultimo)));
}

const resumenDifusion = (d) => d && { id: d.id, mensaje: d.mensaje, estado: d.estado, total: d.pendientes.length + d.enviados.length + d.fallidos.length, enviados: d.enviados.length, fallidos: d.fallidos.length, creada: d.creada, hoy: d.hoy ?? 0, tope: DIFUSION_TOPE_DIA };

/** Cada minuto: si hay una difusión en marcha, manda los siguientes (3 por minuto, en horario, con tope diario). */
export async function difundirUnos(env, store, ahora = new Date()) {
  if (difundiendo) return 0;
  let d = await store.get("difusion:actual");
  if (!d || d.estado !== "enviando" || !env.WA_WEB?.estado?.().ok) return 0;
  const cfg = await leerConfig(store);
  if (!horaDeEscribir(cfg, ahora)) return 0;
  const hoy = relojLocal(cfg, ahora).fecha;
  difundiendo = true;
  let n = 0;
  try {
    for (let i = 0; i < DIFUSION_POR_MINUTO; i++) {
      d = await store.get("difusion:actual"); // Mario pudo pararla mientras tanto
      if (!d || d.estado !== "enviando") break;
      if (d.dia !== hoy) Object.assign(d, { dia: hoy, hoy: 0 });
      if (d.hoy >= DIFUSION_TOPE_DIA) break;
      const sig = d.pendientes.shift();
      if (!sig) {
        d.estado = "terminada"; d.terminada = ahora.toISOString();
        const hist = (await store.get("difusion:historial")) ?? [];
        await store.put("difusion:historial", [{ id: d.id, mensaje: d.mensaje, total: d.enviados.length + d.fallidos.length, enviados: d.enviados.length, fallidos: d.fallidos.length, creada: d.creada, terminada: d.terminada }, ...hist].slice(0, 50));
        await store.put("difusion:actual", d);
        await avisarAMario(env, store, `📣 Difusión terminada: le llegó a ${d.enviados.length}${d.fallidos.length ? ` (${d.fallidos.length} no se pudieron)` : ""}.`, ahora);
        break;
      }
      const l = ((await store.get("leads:index")) ?? {})[sig.clave] ?? {};
      if (l.noPromociones || l.pideBorrar || l.personal) { await store.put("difusion:actual", d); continue; } // cambió mientras tanto
      d.hoy += 1;
      await store.put("difusion:actual", d); // se marca antes de mandar: si algo falla no se le repite
      try {
        await sendMessage(env, store, { channel: "wa", to: sig.id, text: mensajePara(d.mensaje, sig) }, { ahora, autoKey: `difusion:${d.id}` });
        d.enviados.push(sig.clave);
        const rec = (await store.get("difusion:recientes")) ?? {};
        rec[sig.clave] = ahora.toISOString();
        await store.put("difusion:recientes", rec);
        n++;
      } catch (err) {
        d.fallidos.push(sig.clave);
        console.warn(`Difusión (…${sig.id.slice(-4)}): ${err.message ?? err}`);
      }
      await store.put("difusion:actual", d);
      if (i < DIFUSION_POR_MINUTO - 1 && !env.SIN_ESPERA) await new Promise((r) => setTimeout(r, 12000 + Math.random() * 6000)); // ritmo de persona
    }
  } finally { difundiendo = false; }
  return n;
}

// ───────── Revivir clientes: escribirle a quien se enfrió para sacar citas ─────────
// Mario la arranca desde la app (con la lista a la vista). Uno por minuto, en horario de trabajo, con tope diario.
// Antes de escribir, la IA lee el chat: si no es cliente (amigo, postventa…) se lo salta. El mensaje lleva dos horarios
// libres reales y deja el chat en «cita»: si contesta «el martes a las 10», Sofía aparta la cita sola.
const VENTA_EN_CHAT = /\b(city|civic|accord|hr-?v|br-?v|cr-?v|pilot|odyssey|precio|cuanto|credito|financ\w*|enganche|mensualidad\w*|cotiz\w*|informacion|info|auto|carro|camioneta|prueba de manejo|a cuenta|contado|bono|promo\w*)\b/;
const TRAMITE_EN_CHAT = /\b(devoluci\w*|reembolso|placas|factura|ya lo compre|ya la compre|me lo entregaron|me la entregaron|entrega de mi|tramite|gestor)\b/;
let reviviendo = false;

export async function candidatosRevivir(store, ahora = new Date()) {
  const [leads, index, citas] = await Promise.all([store.get("leads:index"), store.get("inbox:index"), store.get("agenda:citas")]);
  const estado = (await store.get("revivir:estado")) ?? {};
  const hechos = new Set([...(estado.enviados ?? []), ...(estado.saltados ?? [])]);
  const conCita = new Set((citas ?? []).filter((x) => x.estado !== "cancelada" && Date.parse(x.id) > ahora.getTime() - 7 * 864e5).map((x) => `${x.canal || "wa"}:${x.cliente}`));
  const sa = (s) => String(s ?? "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase();
  const lista = [];
  for (const [clave, c] of Object.entries(index ?? {})) {
    const l = leads?.[clave] ?? {};
    if (!clave.startsWith("wa:") || hechos.has(clave) || conCita.has(clave)) continue;
    if (l.personal || ["personal", "postventa", "otro"].includes(l.tipo) || l.postventa || l.noPromociones || l.pideBorrar || ["cerrado", "perdido"].includes(l.calor)) continue;
    if (l.revividoAt && ahora - new Date(l.revividoAt) < 14 * 864e5) continue;
    const dias = (ahora - new Date(c.lastAt)) / 864e5;
    if (dias < 2 || dias > 90) continue; // si platicó hace poco, no se le encima
    const msgs = (await store.get(`inbox:c:${clave}`)) ?? [];
    const suyo = sa(msgs.filter((m) => m.dir === "in").map((m) => m.text).join(" "));
    const deMario = sa(msgs.filter((m) => m.dir === "out").map((m) => m.text).join(" "));
    if (TRAMITE_EN_CHAT.test(suyo)) continue;
    if (!(l.tipo === "cliente" || VENTA_EN_CHAT.test(suyo) || /\b(honda|corrida|enganche|cotizacion|prueba de manejo|bono)\b/.test(deMario))) continue;
    const modelo = modeloEn(l.interes || "") || modeloEn(suyo) || modeloEn(deMario) || "";
    lista.push({ clave, id: clave.slice(3), nombre: l.nombreCliente || c.name || l.nombre || "", modelo, dias: Math.round(dias), esperaba: c.lastDir === "in", clasificado: Boolean(l.fondoMotor) });
  }
  // Primero los que se quedaron esperando respuesta, luego los más recientes.
  return lista.sort((a, b) => Number(b.esperaba) - Number(a.esperaba) || a.dias - b.dias);
}

function mensajeRevivir(d, s1, s2, auto, i) {
  const pila = primerNombre(d.nombre);
  const n = /\p{L}{2,}/u.test(pila ?? "") && !/\d/.test(pila) ? pila : ""; // «M.», «..» o emojis: sin nombre
  const { de, lo } = conArticulo(d.modelo);
  const promo = auto?.promo ? ` Este mes ${de} trae ${auto.promo.replace(/\.$/, "")}.` : "";
  // Nos escribió y se quedó sin respuesta: primero una disculpa.
  if (d.esperaba) {
    return [
      `¡Hola${n ? ` ${n}` : ""}! Perdón la demora 🙏 Soy Mario Abarca, de Honda. Con gusto te ayudo con ${de}.${promo} ¿Te queda ${s1} o ${s2} para que ${lo} manejes y te armo la corrida?`,
      `Hola${n ? ` ${n}` : ""}, una disculpa por no contestarte antes 🙏 Aquí Mario de Honda.${promo} Si quieres te espero ${s1} o ${s2} para que ${lo} veas y vemos números. ¿Cuál te acomoda?`,
    ][i % 2];
  }
  const v = [
    `¡Hola${n ? ` ${n}` : ""}! 👋 ¿Cómo vas? Soy Mario Abarca, de Honda. ¿Sigues buscando ${de}?${promo} Me gustaría que ${lo} manejaras sin compromiso y de una vez te armo la corrida a tu medida. ¿Te queda ${s1} o ${s2}?`,
    `Hola${n ? ` ${n}` : ""}, ¿qué tal? Aquí Mario de Honda 🙌 Me acordé de ti por ${de}.${promo} ¿Te aparto un horario para que ${lo} veas y manejes? Tengo ${s1} o ${s2}.`,
    `¡Qué tal${n ? ` ${n}` : ""}! Mario Abarca de Honda por acá. ¿Todavía andas viendo ${de}?${promo} Si gustas te espero ${s1} o ${s2} para que ${lo} pruebes y vemos números.`,
  ];
  return v[i % v.length];
}

/** Dos horarios libres de días distintos (a partir de mañana), rotando para no ofrecerle lo mismo a todos. */
function dosHorarios(libres, ahora, i) {
  const desde = libres.filter((x) => Date.parse(x.id) - ahora.getTime() > 12 * 3600e3);
  if (desde.length < 2) return null;
  const a = desde[(i * 3) % Math.min(desde.length, 12)];
  const b = desde.find((x) => x.fecha !== a.fecha && Date.parse(x.id) > Date.parse(a.id)) ?? desde.find((x) => x.id !== a.id);
  return [a, b].sort((x, y) => x.id.localeCompare(y.id));
}

export async function revivirUno(env, store, ahora = new Date()) {
  const estado = (await store.get("revivir:estado")) ?? {};
  if (!estado.activa || reviviendo) return 0;
  const cfg = await leerConfig(store);
  if (!cfg.activo || !cfg.ventas.activo || !horaDeEscribir(cfg, ahora)) return 0;
  const hoy = relojLocal(cfg, ahora).fecha;
  const hechosHoy = estado.dia === hoy ? estado.hoy ?? 0 : 0;
  if (hechosHoy >= (estado.tope ?? 60)) return 0;
  reviviendo = true;
  // Mientras la IA piensa (hasta ~20 s) Mario puede tocar «Parar»: siempre se relee el estado antes de guardar o mandar.
  const actual = async () => (await store.get("revivir:estado")) ?? {};
  try {
    const [d] = await candidatosRevivir(store, ahora);
    if (!d) { await store.put("revivir:estado", { ...estado, activa: false, terminado: ahora.toISOString() }); return 0; }
    const index = (await store.get("inbox:index")) ?? {};
    // La IA confirma que sea cliente y saca su modelo antes de escribirle.
    let modelo = d.modelo;
    if (!d.clasificado && motoresIA(env, "fondo").length) {
      const { l, r } = await revisarChat(env, store, cfg, d.clave, index[d.clave] ?? {});
      if (r && (l.personal || ["personal", "postventa", "otro"].includes(l.tipo))) {
        const ya = await actual();
        await store.put("revivir:estado", { ...ya, saltados: [...(ya.saltados ?? []), d.clave].slice(-2000) });
        return 0;
      }
      modelo = modeloEn(l.interes || "") || modelo;
      if (!d.nombre && l.nombreCliente) d.nombre = l.nombreCliente;
    }
    const libres = await libresDe(store, cfg, ahora);
    const i = (estado.enviados ?? []).length;
    const par = dosHorarios(libres, ahora, i);
    if (!par) return 0;
    const auto = modelo ? disponiblesInv(await store.get("ventas:inventario")).find((a) => modeloEn(a.modelo) === modelo) : null;
    const texto = mensajeRevivir({ ...d, modelo }, par[0].texto, par[1].texto, auto, i);
    const ya = await actual();
    if (!ya.activa) return 0; // lo pararon mientras tanto
    // Se marca antes de mandar: si algo falla no se le vuelve a escribir.
    await store.put("revivir:estado", { ...ya, dia: hoy, hoy: hechosHoy + 1, enviados: [...(ya.enviados ?? []), d.clave].slice(-2000), ultimo: { nombre: d.nombre, at: ahora.toISOString() } });
    await sendMessage(env, store, { channel: "wa", to: d.id, text: texto }, { ahora, autoKey: "revivir" });
    // El chat queda listo para apartar: «el martes a las 10», «el primero», «sí».
    const idx = (await store.get("inbox:index")) ?? {};
    if (idx[d.clave]) {
      idx[d.clave].venta = { ...(idx[d.clave].venta ?? {}), paso: "cita", desde: ahora.toISOString(), opciones: [`slot:${par[0].id}`, `slot:${par[1].id}`, "otra-hora"], fallos: 0, silencioHasta: undefined, ...(auto ? { autoId: auto.id } : {}) };
      await store.put("inbox:index", idx);
    }
    const leads = (await store.get("leads:index")) ?? {};
    if (leads[d.clave]) { leads[d.clave].revividoAt = ahora.toISOString(); await store.put("leads:index", leads); }
    return 1;
  } catch (e) {
    await anotarError(store, { canal: "wa", id: "revivir" }, `Revivir: ${e.message ?? e}`, ahora);
    return 0;
  } finally { reviviendo = false; }
}
const disponiblesInv = (inv) => (inv ?? []).filter((a) => a && a.disponible !== false);

async function trabajarSola(env, store, ahora) {
  if (!env.WA_WEB?.estado?.().ok) return {};
  const cfg = await leerConfig(store);
  const resumen = await resumenDelDia(env, store, cfg, ahora);
  const seguimientos = await darSeguimiento(env, store, cfg, ahora);
  const revividos = await revivirUno(env, store, ahora);
  difundirUnos(env, store, ahora).catch((e) => console.error("Difusión:", e.message)); // sin esperar: tarda ~40 s
  return { resumen, seguimientos, revividos };
}

/**
 * Publica lo programado que ya venció. La llaman el cron de Cloudflare (cada 5 min) y servidor.mjs (cada minuto),
 * así funciona aunque la app esté cerrada. Si no hay nada que publicar no escribe nada (cuida el límite gratis de KV).
 * baseUrl: dirección pública del conector si no hay PUBLIC_URL (si falta, la que se guardó al programar).
 * soloId: publicar solo esa ("Publicar ahora"); lo demás vencido queda para el programador.
 */
export async function runScheduled(envBase, store, ahoraISO = new Date().toISOString(), baseUrl = "", soloId = null) {
  const env = await conConexion(envBase, store);
  const ahora = new Date(ahoraISO);
  const recordatorios = soloId ? 0 : await recordarCitas(env, store, ahora);
  if (!soloId) await dispararRecordatorios(env, store, ahora).catch((e) => console.error("Recordatorios de Mario:", e.message));
  if (!soloId) await trabajarSola(env, store, ahora).catch((e) => console.error("Trabajo solo:", e.message));
  if (!soloId && env.WA_WEB?.estado?.().ok) trabajoDeFondo(env, store, ahora).catch((e) => console.error("Fondo:", e.message)); // sin esperar: la IA local puede tardar
  const cola = (await store.get("social:cola")) ?? [];
  const vencidas = cola.filter((x) => (!soloId || x.id === soloId) && ((x.estado === "pendiente" && new Date(x.siguiente ?? x.cuando) <= ahora)
    || (x.estado === "publicando" && ahora - new Date(x.bloqueo) > BLOQUEO_MS)));
  if (!vencidas.length) return { revisadas: cola.length, publicadas: 0, fallidas: 0, recordatorios };

  // Se apartan antes de llamar a Meta para que otra corrida simultánea no las publique dos veces.
  const intentar = [];
  for (const x of vencidas) {
    if ((x.intentos ?? 0) >= MAX_INTENTOS) { x.estado = "error"; delete x.bloqueo; continue; } // se cayó a media publicación demasiadas veces
    Object.assign(x, { estado: "publicando", bloqueo: ahora.toISOString(), intentos: (x.intentos ?? 0) + 1 });
    intentar.push(x);
  }
  await store.put("social:cola", cola);

  for (const x of intentar) await publicarProgramada(env, store, x, publicBase(env, baseUrl || x.base), ahora);

  // La cola pudo cambiar mientras se publicaba (la app programó otra): se mezcla por id.
  const porId = new Map(vencidas.map((x) => [x.id, x]));
  const actual = (await store.get("social:cola")) ?? [];
  await store.put("social:cola", actual.map((x) => porId.get(x.id) ?? x));
  return { revisadas: cola.length, publicadas: vencidas.filter((x) => x.estado === "publicado").length, fallidas: vencidas.filter((x) => x.estado !== "publicado").length, recordatorios };
}

async function status(env, store, ahora) {
  const out = { ok: true, version: VERSION, whatsapp: { configured: waReady(env) }, facebook: { configured: fbReady(env) }, instagram: { configured: igReady(env) }, webhook: { secret: Boolean(env.META_APP_SECRET), verifyToken: Boolean(env.META_VERIFY_TOKEN), last: await store.get("webhook:last") }, publicUrl: env.PUBLIC_URL || null };
  const cfg = await leerConfig(store);
  const errores = (await store.get("agente:errores")) ?? [];
  const inventario = (await store.get("ventas:inventario")) ?? [];
  out.agente = { activo: cfg.activo, enHorario: enHorario(cfg, ahora), reglas: cfg.reglas.length, ultimoError: errores[0] ?? null, ventas: { activo: cfg.ventas.activo, autos: inventario.filter((a) => a.disponible !== false).length, ia: { activa: Boolean(cfg.ventas.ia), motor: motorIA(env), motores: motoresIA(env), llave: Boolean(motorIA(env)), modelo: motorIA(env) === "claude" ? env.ANTHROPIC_MODEL || MODELO_IA : motorIA(env) === "cloudflare" ? env.CF_AI_MODEL || MODELO_GRATIS : null } } };
  const nuevos = Object.values((await store.get("leads:index")) ?? {}).filter((l) => !l.importado);
  out.prospectos = { nuevos: nuevos.length, calientes: nuevos.filter((l) => l.cita || l.quiereAsesor).length };
  const cola = (await store.get("social:cola")) ?? [];
  out.programadas = { pendientes: cola.filter((x) => x.estado === "pendiente" || x.estado === "publicando").length, conError: cola.filter((x) => x.estado === "error").length };
  const coex = await store.get("coex:estado");
  if (coex) {
    const h = await store.get("coex:historial");
    out.coexistencia = { ...coex, historial: h ? { mensajes: h.mensajes, chats: h.hilos.length, delAsesor: h.delAsesor, progreso: h.progreso, error: h.error ?? null } : null, aprendidos: cfg.estilo?.deChats?.length ?? 0 };
  }
  if (env.WA_WEB?.estado) Object.assign(out.whatsapp, env.WA_WEB.estado());
  else if (waReady(env)) {
    try {
      const p = await graph(env, `${env.WA_PHONE_NUMBER_ID}?fields=display_phone_number,verified_name,quality_rating`, { token: env.WA_TOKEN });
      Object.assign(out.whatsapp, { ok: true, phone: p.display_phone_number, name: p.verified_name, quality: p.quality_rating });
    } catch (e) { Object.assign(out.whatsapp, { ok: false, error: e.message }); }
  }
  if (fbReady(env)) {
    try {
      const p = await graph(env, `${env.FB_PAGE_ID}?fields=name,link`, { token: env.FB_PAGE_TOKEN });
      Object.assign(out.facebook, { ok: true, name: p.name, link: p.link });
    } catch (e) { Object.assign(out.facebook, { ok: false, error: e.message }); }
  }
  if (igReady(env)) {
    try {
      const p = await graph(env, `${env.IG_USER_ID}?fields=username`, { token: env.FB_PAGE_TOKEN });
      Object.assign(out.instagram, { ok: true, username: p.username });
    } catch (e) { Object.assign(out.instagram, { ok: false, error: e.message }); }
  }
  return out;
}

// ───────── Router ─────────

/**
 * store: { get(key) → objeto|null, put(key, objeto), delete?(key) }
 * opciones: { ahora } fecha fija (ISO, Date o función) para probar horarios; si falta, la hora real.
 * Rutas de la app: token en ?token= (GET) o en el cuerpo JSON (POST, enviado como text/plain para evitar CORS preflight).
 */
export async function handle(req, envBase, store, opciones = {}) {
  const url = new URL(req.url);
  const path = url.pathname.replace(/\/+$/, "") || "/";
  // Los datos de Meta guardados desde la app solo hacen falta para el webhook y la API (no para fotos públicas ni archivos).
  const env = path === "/webhook/meta" || (path.startsWith("/api/") && path !== "/api/salud") ? await conConexion(envBase, store) : envBase;
  const ahora = ahoraDe(opciones);
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: CORS });

  // Webhook de Meta (WhatsApp y Messenger)
  if (path === "/webhook/meta") {
    if (req.method === "GET") {
      const ok = url.searchParams.get("hub.mode") === "subscribe" && env.META_VERIFY_TOKEN && sameSecret(url.searchParams.get("hub.verify_token"), env.META_VERIFY_TOKEN);
      return ok ? new Response(url.searchParams.get("hub.challenge") ?? "", { status: 200 }) : new Response("Token de verificación incorrecto", { status: 403 });
    }
    if (req.method === "POST") return handleWebhook(req, env, store, ahora);
    return fail("Método no permitido", 405);
  }
  // Fotos de publicaciones programadas: PÚBLICAS (sin clave) porque Instagram las descarga de una URL.
  // El id es aleatorio de 128 bits, así que no se pueden adivinar.
  if (path.startsWith("/media/")) {
    if (req.method !== "GET" && req.method !== "HEAD") return fail("Método no permitido", 405);
    const id = path.slice("/media/".length);
    const foto = MEDIA_ID.test(id) ? await store.get(`media:${id}`) : null;
    if (!foto?.datos || !FOTOS.includes(foto.mime)) return new Response("No encontrado", { status: 404, headers: { "content-type": "text/plain; charset=utf-8", ...CORS } });
    return new Response(deBase64(foto.datos), { headers: { "content-type": foto.mime, "cache-control": "public, max-age=3600", "x-content-type-options": "nosniff", ...CORS } });
  }
  if (path === "/api/salud") return json({ ok: true, version: VERSION });
  if (!path.startsWith("/api/")) return null; // lo demás: archivos estáticos (lo decide el envoltorio)

  let body = {};
  if (req.method === "POST") {
    try { body = JSON.parse(await req.text()); } catch { return fail("JSON inválido"); }
  }
  const token = req.method === "GET" ? url.searchParams.get("token") : body.token;
  if (!env.SOFIA_TOKEN) return fail("El servidor no tiene SOFIA_TOKEN configurado", 500);
  if (!sameSecret(token, env.SOFIA_TOKEN)) return fail("Clave incorrecta", 401);

  try {
    switch (`${req.method} ${path}`) {
      case "GET /api/estado": return json(await status(env, store, ahora));
      case "GET /api/datos": {
        const doc = await store.get("datos:main");
        if (!doc) return json({ ok: true, updatedAt: null, backup: null });
        return json(url.searchParams.get("meta") ? { ok: true, updatedAt: doc.updatedAt } : { ok: true, ...doc });
      }
      case "POST /api/datos": {
        if (body.backup?.app !== "sofia-prueba") return fail("No es un respaldo de Sofía");
        const prev = await store.get("datos:main");
        if (prev) await store.put("datos:prev", prev);
        const updatedAt = new Date().toISOString();
        await store.put("datos:main", { updatedAt, backup: body.backup });
        return json({ ok: true, updatedAt });
      }
      case "GET /api/buzon": return json({ ok: true, conversations: (await store.get("inbox:index")) ?? {} });
      case "GET /api/buzon/conversacion": {
        const key = url.searchParams.get("c") ?? "";
        if (!/^(wa|fb):[\w.-]+$/.test(key)) return fail("Conversación inválida");
        return json({ ok: true, messages: (await store.get(`inbox:c:${key}`)) ?? [] });
      }
      case "POST /api/buzon/sincronizar": {
        if (!env.WA_WEB?.sincronizarPendientes) return fail("La sincronización de chats pendientes requiere WhatsApp Web vinculado.", 409);
        const sincronizado = await env.WA_WEB.sincronizarPendientes({ todos: body.todos === true });
        await procesarEventos(sincronizado.body, env, store, ahora, publicBase(env, baseDe(req)), { autoResponder: false });
        return json({ ok: true, chats: sincronizado.chats, mensajes: sincronizado.mensajes, fijados: sincronizado.fijados ?? [], respondidos: 0 });
      }
      case "GET /api/whatsapp/etiquetas": {
        if (!env.WA_WEB?.etiquetas) return fail("Requiere WhatsApp Web vinculado.", 409);
        return json({ ok: true, etiquetas: await env.WA_WEB.etiquetas() });
      }
      case "POST /api/whatsapp/etiquetar-todo": {
        // Cada chat con: el MES en que llegó, su MODELO, y Postventa / Caliente / Cita; «No leído» a los que tienen sin leer.
        // Nunca quita etiquetas. ver=true solo cuenta lo que pondría.
        if (!env.WA_WEB?.etiquetarTodo) return fail("Requiere WhatsApp Web vinculado.", 409);
        const plan = await planDeEtiquetas(store, await leerConfig(store), ahora);
        if (body.ver) {
          const cuenta = {};
          for (const p of plan) for (const n of p.etiquetas) cuenta[n] = (cuenta[n] ?? 0) + 1;
          return json({ ok: true, chats: plan.length, cuenta, existentes: (await env.WA_WEB.etiquetas()).map((l) => l.nombre) });
        }
        return json({ ok: true, ...(await env.WA_WEB.etiquetarTodo({ plan, alias: ALIAS_ETIQUETAS, crear: body.crear !== false })) });
      }
      case "POST /api/difusion": {
        // ver: cuántos y quiénes con esos filtros · iniciar: arranca (solo con la lista que Mario vio) · parar / seguir · estado
        const accion = body.accion ?? "estado";
        const actual = await store.get("difusion:actual");
        if (accion === "estado") return json({ ok: true, actual: resumenDifusion(actual), historial: ((await store.get("difusion:historial")) ?? []).slice(0, 10) });
        if (accion === "parar" || accion === "seguir") {
          if (!actual || actual.estado === "terminada") return fail("No hay una difusión en marcha.", 409);
          actual.estado = accion === "parar" ? "parada" : "enviando";
          await store.put("difusion:actual", actual);
          return json({ ok: true, actual: resumenDifusion(actual) });
        }
        const cfg = await leerConfig(store);
        const propio = String(env.WA_WEB?.estado?.()?.phone ?? "").replace(/\D/g, "");
        const lista = await audienciaDifusion(store, cfg, body.filtros ?? {}, ahora, { propio });
        const mensaje = String(body.mensaje ?? "").trim().slice(0, 1500);
        if (accion === "ver") {
          return json({ ok: true, total: lista.length, lista: lista.slice(0, DIFUSION_MAX).map(({ clave, nombre, modelo, calor, mes }) => ({ clave, nombre, modelo, calor, mes, final: clave.slice(-4) })), ejemplo: mensaje && lista[0] ? mensajePara(mensaje, lista[0]) : "", actual: resumenDifusion(actual) });
        }
        if (accion === "iniciar") {
          if (actual && ["enviando", "parada"].includes(actual.estado)) return fail("Ya hay una difusión en marcha: párala o espera a que termine.", 409);
          if (mensaje.length < 5) return fail("Escribe el mensaje.");
          if (!env.WA_WEB?.estado?.().ok) return fail("WhatsApp no está vinculado en el servidor.", 409);
          const elegidos = Array.isArray(body.claves) ? new Set(body.claves) : null;
          const pendientes = lista.filter((x) => !elegidos || elegidos.has(x.clave)).slice(0, DIFUSION_MAX).map(({ clave, id, nombre, modelo }) => ({ clave, id, nombre, modelo }));
          if (!pendientes.length) return fail("No hay a quién mandarle con esos filtros.");
          const d = { id: `d${ahora.getTime().toString(36)}`, mensaje, filtros: body.filtros ?? {}, pendientes, enviados: [], fallidos: [], estado: "enviando", creada: ahora.toISOString(), dia: relojLocal(cfg, ahora).fecha, hoy: 0 };
          await store.put("difusion:actual", d);
          return json({ ok: true, actual: resumenDifusion(d), enHorario: horaDeEscribir(cfg, ahora) });
        }
        return fail("Acción desconocida.");
      }
      case "POST /api/jarvis": {
        const texto = String(body.texto ?? "").trim().slice(0, 1000);
        if (!texto) return fail("Escribe qué quieres que haga Sofía.");
        return json({ ok: true, ...(await ordenJarvis(env, store, texto, ahora)) });
      }
      case "GET /api/jarvis/recordatorios":
        return json({ ok: true, recordatorios: await recordatoriosPendientes(store) });
      case "POST /api/jarvis/recordatorio": {
        const lista = (await store.get("jarvis:recordatorios")) ?? [];
        const r = lista.find((x) => x.id === body.id);
        if (!r) return fail("No encontré ese recordatorio.", 404);
        if (body.hecho) r.hecho = true;
        await store.put("jarvis:recordatorios", lista);
        return json({ ok: true, recordatorio: r });
      }
      case "POST /api/revivir": {
        // ver: a quién y qué se le mandaría · iniciar: arranca (tope por día) · parar: se detiene en el acto.
        const estado = (await store.get("revivir:estado")) ?? {};
        const accion = String(body.accion ?? "ver");
        if (accion === "parar") { await store.put("revivir:estado", { ...estado, activa: false }); return json({ ok: true, activa: false }); }
        if (accion === "iniciar") {
          const tope = Math.max(1, Math.min(150, Number(body.tope) || 60));
          await store.put("revivir:estado", { ...estado, activa: true, tope, inicio: ahora.toISOString() });
          return json({ ok: true, activa: true, tope });
        }
        const cfg = await leerConfig(store);
        const lista = await candidatosRevivir(store, ahora);
        const par = dosHorarios(await libresDe(store, cfg, ahora), ahora, 0);
        const ejemplo = lista[0] && par ? mensajeRevivir(lista[0], par[0].texto, par[1].texto, null, 0) : "";
        const hoy = relojLocal(cfg, ahora).fecha;
        return json({ ok: true, total: lista.length, muestra: lista.slice(0, 40).map((d) => ({ nombre: d.nombre, modelo: d.modelo, dias: d.dias, esperaba: d.esperaba, final: d.id.slice(-4) })), ejemplo,
          estado: { activa: Boolean(estado.activa), tope: estado.tope ?? 60, hoy: estado.dia === hoy ? estado.hoy ?? 0 : 0, enviados: (estado.enviados ?? []).length, saltados: (estado.saltados ?? []).length, ultimo: estado.ultimo ?? null, enHorario: horaDeEscribir(cfg, ahora) } });
      }
      case "POST /api/resumen/enviar": {
        // «sofia resumen» o el botón de la app: el resumen del día, ahora mismo, al chat «Tú» de Mario.
        if (!env.WA_WEB?.estado?.().ok) return fail("El resumen necesita el WhatsApp de Mario vinculado.", 409);
        const enviado = await resumenDelDia(env, store, await leerConfig(store), ahora, true);
        if (!enviado) return fail("No pude mandar el resumen.", 409);
        return json({ ok: true });
      }
      case "POST /api/buzon/responder": {
        const clave = String(body.clave ?? "");
        if (!/^wa:[\w.-]+$/.test(clave)) return fail("Conversación de WhatsApp inválida");
        const mensajes = (await store.get(`inbox:c:${clave}`)) ?? [];
        const ultimo = mensajes.at(-1);
        if (!ultimo || ultimo.dir !== "in") return fail("No hay un mensaje pendiente del cliente.", 409);
        if (ahora - new Date(ultimo.at) > 30 * DIA_MS) return fail("Ese mensaje tiene más de 30 días; revísalo y responde manualmente.", 409);
        const cfg = await leerConfig(store);
        if (!cfg.activo || !cfg.ventas.activo) return fail("Activa primero las respuestas automáticas y Vender autos.", 409);
        const prev = ((await store.get("inbox:index")) ?? {})[clave] ?? null;
        if (!env.WA_WEB && ahora - new Date(prev?.lastInAt ?? 0) >= 24 * 60 * 60 * 1000) return fail("La ventana de 24 horas de la API de WhatsApp venció. Usa una plantilla aprobada o espera a que el cliente vuelva a escribir.", 409);
        const peer = clave.slice(3);
        const enviado = await responderVentas(env, store, cfg, { canal: "wa", id: peer, nombre: prev?.name ?? "", texto: ultimo.text, at: ahora.toISOString(), primero: false, prev }, ahora, publicBase(env, baseDe(req)));
        if (!enviado) return fail("Sofía no envió respuesta. Puede que Mario ya haya contestado, la conversación esté pausada o falte información.", 409);
        return json({ ok: true, enviado: true });
      }
      case "POST /api/whatsapp/etiquetar": {
        if (!env.WA_WEB?.etiquetar) return fail("Las etiquetas de WhatsApp requieren el conector por dispositivo vinculado.", 409);
        const clave = String(body.clave ?? "");
        if (!/^wa:\d{6,15}$/.test(clave)) return fail("Conversación de WhatsApp inválida");
        const permitidas = new Set(["Prospecto", "Caliente", "Cita", "Asesor"]);
        const etiquetas = Array.isArray(body.etiquetas) ? body.etiquetas.filter((x) => permitidas.has(x)) : [];
        if (!etiquetas.length) return fail("Elige al menos una etiqueta conocida.");
        const aplicadas = await env.WA_WEB.etiquetar({ to: clave.slice(3), etiquetas });
        if (!aplicadas.length) return fail("No encontré esas etiquetas en WhatsApp Business. Créala allí primero.", 409);
        return json({ ok: true, aplicadas });
      }
      case "POST /api/whatsapp/etiquetar-no-leidos": {
        if (!env.WA_WEB?.etiquetarNoLeidos) return fail("La acción de etiquetar no leídos requiere WhatsApp Web vinculado.", 409);
        return json({ ok: true, ...(await env.WA_WEB.etiquetarNoLeidos()) });
      }
      case "POST /api/ia/cloudflare/probar": {
        const ai = env.AI?.run ? env.AI : iaPorApi({ cuenta: env.CF_ACCOUNT_ID, llave: env.CF_API_TOKEN });
        if (!ai) return fail("Guarda primero el Account ID y el token de Workers AI.", 409);
        await ai.run(MODELO_GRATIS, { messages: [{ role: "user", content: 'Responde únicamente con este JSON: {"conectada":true}' }], max_tokens: 32, temperature: 0 });
        return json({ ok: true, motor: "cloudflare", modelo: MODELO_GRATIS });
      }
      case "POST /api/ia/local/probar": {
        if (!/^https?:\/\/\S+$/.test(String(env.LOCAL_AI_URL ?? ""))) return fail("Guarda primero la dirección de tu IA local.", 409);
        const inicio = Date.now();
        try { await preguntarLocal(env, { system: "Eres una prueba de conexión.", messages: [{ role: "user", content: "di hola" }] }); }
        catch (e) { if (!/formato|JSON/i.test(e.message ?? "")) return fail(e.message ?? String(e), 502); } // contestó, aunque no en JSON
        return json({ ok: true, motor: "local", modelo: env.LOCAL_AI_MODEL || MODELO_LOCAL, segundos: Math.round((Date.now() - inicio) / 1000) });
      }
      case "POST /api/enviar": return json({ ok: true, ...(await sendMessage(env, store, body, { ahora })) });
      case "GET /api/wa/plantillas": {
        if (!env.WA_WABA_ID || !env.WA_TOKEN) return fail("Falta WA_WABA_ID para leer plantillas");
        const r = await graph(env, `${env.WA_WABA_ID}/message_templates?fields=name,language,status,category,components&limit=100`, { token: env.WA_TOKEN });
        return json({ ok: true, templates: (r.data ?? []).filter((t) => t.status === "APPROVED") });
      }
      case "GET /api/media": {
        const id = url.searchParams.get("id") ?? "";
        if (!/^\d+$/.test(id) || !waReady(env)) return fail("Archivo inválido");
        const meta = await graph(env, id, { token: env.WA_TOKEN });
        const file = await fetch(meta.url, { headers: { authorization: `Bearer ${env.WA_TOKEN}` } });
        if (!file.ok) return fail("No se pudo descargar el archivo de WhatsApp", 502);
        // Lo manda cualquiera que escriba al número: un HTML o SVG nunca debe abrirse como página.
        const tipo = String(meta.mime_type ?? "").split(";")[0].trim().toLowerCase();
        return new Response(file.body, { headers: { "content-type": MEDIA_SEGURA.test(tipo) ? tipo : "application/octet-stream", "content-disposition": "attachment", "x-content-type-options": "nosniff", "cache-control": "no-store", ...CORS } });
      }
      case "POST /api/facebook/publicar": return json({ ok: true, ...(await publishPost(env, store, body)) });
      case "GET /api/facebook/publicaciones": return json({ ok: true, posts: (await store.get("fb:posts")) ?? [] });

      // Agente sin IA
      case "POST /api/meta/coexistencia": return json({ ok: true, ...(await conectarCoexistencia(envBase, store, baseDe(req), body, ahora)) });
      case "GET /api/agente/config": return json({ ok: true, config: await leerConfig(store) });
      case "POST /api/agente/config": {
        if (!body.config || typeof body.config !== "object") return fail("Falta la configuración");
        const prev = await leerConfig(store);
        const config = normalizarConfig({ ...prev, ...body.config, horario: { ...prev.horario, ...(body.config.horario ?? {}) }, ventas: { ...prev.ventas, ...(body.config.ventas ?? {}) }, estilo: { ...prev.estilo, ...(body.config.estilo ?? {}) } });
        await store.put("agente:config", config);
        return json({ ok: true, config });
      }

      // Datos de Meta y de la IA desde la app (Más → Conexiones)
      case "GET /api/conexion": return json({ ok: true, ...(await vistaConexion(envBase, store, baseDe(req))) });
      case "POST /api/conexion": {
        await guardarConexion(envBase, store, body.datos);
        return json({ ok: true, ...(await vistaConexion(envBase, store, baseDe(req))) });
      }

      // Inventario de la vendedora (lo administra la app)
      case "GET /api/inventario": {
        const base = publicBase(env, baseDe(req));
        return json({ ok: true, autos: ((await store.get("ventas:inventario")) ?? []).map((a) => vistaAuto(a, base)) });
      }
      case "POST /api/inventario": {
        const base = publicBase(env, baseDe(req));
        return json({ ok: true, autos: (await guardarInventario(store, body.autos)).map((a) => vistaAuto(a, base)) });
      }
      case "POST /api/inventario/foto": {
        // Se sirve en público (/media/<id>) para que WhatsApp la descargue; el id es aleatorio de 128 bits.
        const m = /^data:([\w/+.-]+);base64,([A-Za-z0-9+/=\s]+)$/.exec(String(body.imagen ?? ""));
        if (!m || !["image/jpeg", "image/png"].includes(m[1])) return fail("La foto debe ser JPG o PNG");
        const datos = m[2].replace(/\s+/g, "");
        if (datos.length * 0.75 > MAX_FOTO_AUTO) return fail("La foto pesa más de 5 MB (WhatsApp no la acepta)");
        const fotoId = nuevoId();
        await store.put(`media:${fotoId}`, { mime: m[1], datos });
        return json({ ok: true, fotoId, foto: `${publicBase(env, baseDe(req))}/media/${fotoId}` });
      }

      // Citas que agendó Sofía (la app las muestra en Hoy)
      case "GET /api/agenda": return json({ ok: true, citas: (await citasActivas(store, ahora)).sort((a, b) => a.id.localeCompare(b.id)) });
      case "POST /api/agenda/cancelar": {
        const citas = (await store.get("agenda:citas")) ?? [];
        const x = citas.find((c) => c.id === body.id && c.cliente === body.cliente && c.estado === "apartada");
        if (!x) return fail("Esa cita ya no está", 404);
        x.estado = "cancelada";
        await store.put("agenda:citas", citas);
        return json({ ok: true });
      }

      // "Probar a Sofía" desde la app: el mismo camino que un mensaje real (menú + IA del servidor), sin guardar ni enviar nada.
      case "POST /api/vendedora/probar": {
        const cfg = await leerConfig(store);
        const inventario = await inventarioVendedora(store, publicBase(env, baseDe(req)), false);
        const historial = (Array.isArray(body.historial) ? body.historial : []).slice(-30).map((m) => ({ dir: m?.dir === "out" ? "out" : "in", text: String(m?.text ?? "").slice(0, 1500) }));
        const conv = body.conv && typeof body.conv === "object" && !Array.isArray(body.conv) ? body.conv : {};
        const r = await pensarVenta(env, cfg, inventario, conv, { texto: String(body.texto ?? "").slice(0, 1500), nombre: String(body.nombre ?? "").slice(0, 60), primero: Boolean(body.primero) }, async () => historial, ahora, await libresDe(store, cfg, ahora));
        return json({ ok: true, ...r });
      }

      // Prospectos (contactos nuevos que escribieron por WhatsApp o Messenger)
      case "GET /api/prospectos": {
        const leads = (await store.get("leads:index")) ?? {};
        const prospectos = Object.entries(leads).map(([clave, l]) => ({ clave, ...l })).sort((a, b) => b.at.localeCompare(a.at));
        return json({ ok: true, prospectos });
      }
      case "POST /api/prospectos/marcar": {
        if (!Array.isArray(body.ids)) return fail("Faltan los prospectos a marcar (ids)");
        const leads = (await store.get("leads:index")) ?? {};
        const importado = body.importado !== false;
        let marcados = 0;
        for (const clave of body.ids) {
          const l = typeof clave === "string" && Object.hasOwn(leads, clave) ? leads[clave] : null; // "__proto__" no es un prospecto
          if (!l || l.importado === importado) continue;
          l.importado = importado;
          if (importado) l.importadoAt = ahora.toISOString(); else delete l.importadoAt;
          marcados++;
        }
        if (marcados) await store.put("leads:index", leads);
        return json({ ok: true, marcados });
      }
      case "POST /api/prospectos/actualizar": {
        // Mario acomoda al cliente en su tablero (temperatura, nota, nombre). Lo que él decide, Sofía ya no lo cambia.
        const leads = (await store.get("leads:index")) ?? {};
        const clave = String(body.clave ?? "");
        const l = Object.hasOwn(leads, clave) ? leads[clave] : null;
        if (!l) return fail("No encontré ese cliente", 404);
        if (body.calor !== undefined) {
          if (!["caliente", "tibio", "frio", "cerrado", "perdido"].includes(body.calor)) return fail("Temperatura inválida");
          Object.assign(l, { calor: body.calor, calorManual: true });
        }
        if (body.nota !== undefined) l.nota = String(body.nota).slice(0, 500);
        if (body.nombreCliente !== undefined) l.nombreCliente = String(body.nombreCliente).trim().slice(0, 60);
        // «Es amigo» / «Es cliente»: lo que decide Mario manda sobre las reglas y la IA (fondoMotor «mario» = no se recalifica).
        if (body.personal !== undefined) Object.assign(l, { personal: Boolean(body.personal), tipo: body.personal ? "personal" : "cliente", fondoMotor: "mario", tipoManual: true });
        l.actualizado = ahora.toISOString();
        await store.put("leads:index", leads);
        return json({ ok: true, prospecto: { clave, ...l } });
      }

      // Programador de publicaciones
      case "POST /api/social/programar": {
        const base = baseDe(req);
        const item = await programar(env, store, body.post, base, ahora);
        // Si ya es hora ("publicar ahora"), sale de una vez SOLO esta; si falla, el programador la reintenta.
        if (new Date(item.cuando) <= ahora) await runScheduled(env, store, ahora.toISOString(), base, item.id);
        const final = ((await store.get("social:cola")) ?? []).find((x) => x.id === item.id) ?? item;
        return json({ ok: true, item: vistaCola(env, final, base) });
      }
      case "GET /api/social/cola": {
        const base = baseDe(req);
        const cola = ((await store.get("social:cola")) ?? []).map((x) => vistaCola(env, x, base)).sort((a, b) => a.cuando.localeCompare(b.cuando));
        return json({ ok: true, cola });
      }
      case "POST /api/social/cancelar": {
        const cola = (await store.get("social:cola")) ?? [];
        const item = cola.find((x) => x.id === body.id);
        if (!item) return fail("Esa publicación ya no está en la cola", 404);
        if (item.estado === "publicando") return fail("Se está publicando en este momento; intenta en un minuto", 409);
        await store.put("social:cola", cola.filter((x) => x !== item));
        if (item.mediaId) await borrar(store, `media:${item.mediaId}`);
        return json({ ok: true });
      }
      default: return fail("Ruta no encontrada", 404);
    }
  } catch (e) {
    return fail(e.message ?? String(e), e.status ?? 502);
  }
}
