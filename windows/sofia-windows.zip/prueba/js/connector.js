// Cliente del conector (prueba/servidor): WhatsApp Business, Messenger y Facebook reales.
// La app nunca guarda tokens de Meta: solo la dirección del conector y su clave.
import { state, persist, serverBase, isAppsScript } from "./store.js";

export const connectorReady = () => Boolean(serverBase() && !isAppsScript() && state.settings.server.token);
/** Lo último que respondió el conector (para decidir qué mostrar sin esperar a la red). */
export const lastStatus = () => state.settings.server.status ?? null;
export const waReady = () => connectorReady() && Boolean(lastStatus()?.whatsapp?.configured);
export const fbReady = () => connectorReady() && Boolean(lastStatus()?.facebook?.configured);
export const igReady = () => connectorReady() && Boolean(lastStatus()?.instagram?.configured);

async function call(path, { method = "GET", params = {}, body } = {}) {
  if (!connectorReady()) throw new Error("Conecta tu servidor en Más → Conexiones.");
  const u = new URL(`${serverBase()}${path}`);
  if (method === "GET") {
    u.searchParams.set("token", state.settings.server.token);
    for (const [k, v] of Object.entries(params)) u.searchParams.set(k, v);
  }
  let res;
  try {
    res = await fetch(u, method === "GET"
      ? { cache: "no-store" }
      : { method, headers: { "content-type": "text/plain;charset=utf-8" }, body: JSON.stringify({ ...body, token: state.settings.server.token }) });
  } catch {
    throw new Error("No hay conexión con tu servidor. Revisa internet o la dirección en Conexiones.");
  }
  if ((res.headers.get("content-type") ?? "").includes("application/json")) {
    const data = await res.json();
    if (!res.ok || data.ok === false) throw new Error(data.error || `El servidor respondió ${res.status}`);
    return data;
  }
  if (!res.ok) throw new Error(`El servidor respondió ${res.status}`);
  return res;
}

export async function refreshStatus() {
  const st = await call("/api/estado");
  state.settings.server.status = {
    at: new Date().toISOString(), whatsapp: st.whatsapp, facebook: st.facebook, instagram: st.instagram, webhook: st.webhook, version: st.version,
    agente: st.agente, coexistencia: st.coexistencia, prospectos: st.prospectos, programadas: st.programadas, publicUrl: st.publicUrl,
  };
  persist(); // es estado de la conexión, no un cambio de datos: no tapa respaldos más nuevos
  return st;
}

export const inbox = async () => (await call("/api/buzon")).conversations;
export const conversation = async (key) => (await call("/api/buzon/conversacion", { params: { c: key } })).messages;
export const syncPendingChats = () => call("/api/buzon/sincronizar", { method: "POST", body: {} });
export const replyToPending = (clave) => call("/api/buzon/responder", { method: "POST", body: { clave } });
export const revivir = (accion = "ver", extra = {}) => call("/api/revivir", { method: "POST", body: { accion, ...extra } });
export const etiquetarTodo = (extra = {}) => call("/api/whatsapp/etiquetar-todo", { method: "POST", body: extra });
export const difusion = (accion = "estado", extra = {}) => call("/api/difusion", { method: "POST", body: { accion, ...extra } });
export const jarvis = (texto) => call("/api/jarvis", { method: "POST", body: { texto } });
export const recordatorios = () => call("/api/jarvis/recordatorios").then((r) => r.recordatorios ?? []);
export const recordatorioHecho = (id) => call("/api/jarvis/recordatorio", { method: "POST", body: { id, hecho: true } });
export const labelConversation = (clave, etiquetas) => call("/api/whatsapp/etiquetar", { method: "POST", body: { clave, etiquetas } });
export const labelUnreadChats = () => call("/api/whatsapp/etiquetar-no-leidos", { method: "POST", body: {} });
export const sendMessage = (msg) => call("/api/enviar", { method: "POST", body: msg });
export const testCloudflareAI = () => call("/api/ia/cloudflare/probar", { method: "POST", body: {} });
export const testLocalAI = () => call("/api/ia/local/probar", { method: "POST", body: {} });
export const salesInventory = async () => (await call("/api/inventario")).autos;
export const waTemplates = async () => (await call("/api/wa/plantillas")).templates;
export const publishPost = (post) => call("/api/facebook/publicar", { method: "POST", body: post });
export const listPosts = async () => (await call("/api/facebook/publicaciones")).posts;

// ── Agente sin IA del conector: contesta solo en WhatsApp/Messenger aunque la app esté cerrada ──
/** { activo, zonaHoraria, horario { dias, inicio, fin }, bienvenida, fueraDeHorario, reglas [{ palabras, respuesta }], esperaHoras, pausaMinutos, asesor, agencia } */
export const getAgentConfig = async () => (await call("/api/agente/config")).config;
/** Guarda solo lo que cambies (lo demás se conserva). Devuelve la configuración completa ya validada. */
export const setAgentConfig = async (config) => (await call("/api/agente/config", { method: "POST", body: { config } })).config;

// ── Datos de Meta y de la IA guardados en el servidor desde Conexiones (sin tocar Cloudflare) ──
/** { configurado: { WA_TOKEN: "app"|"servidor"|null, … }, valores (solo los que no son secretos), webhook: { url, verifyToken } } */
export const getConnection = () => call("/api/conexion");
/** datos: { WA_TOKEN, WA_PHONE_NUMBER_ID, … } — vacío borra ese dato. Devuelve lo mismo que getConnection. */
export const saveConnection = (datos) => call("/api/conexion", { method: "POST", body: { datos } });
/** Termina la conexión del WhatsApp Business del asesor (coexistencia) con el código de la ventana de Meta. */
export const connectCoexistence = (datos) => call("/api/meta/coexistencia", { method: "POST", body: datos });

// ── Inventario de la vendedora: lo que Sofía ofrece por WhatsApp ──
/** autos: [{ id, marca, modelo, version, anio, precio, tipo, km, color, transmision, descripcion, palabras, disponible, fotoId? }] */
export const saveInventory = async (autos) => (await call("/api/inventario", { method: "POST", body: { autos } })).autos;
/** imagen: data URL JPG/PNG (máx. 5 MB). Devuelve { fotoId, foto (URL pública) }. */
export const uploadCarPhoto = (imagen) => call("/api/inventario/foto", { method: "POST", body: { imagen } });

/** Citas que agendó Sofía: [{ id (ISO), texto, canal, cliente, nombre, interes, resumen, estado }] de la más próxima a la más lejana. */
export const getAgenda = async () => (await call("/api/agenda")).citas;
export const cancelCita = (cita) => call("/api/agenda/cancelar", { method: "POST", body: { id: cita.id, cliente: cita.cliente } });

/** "Probar a Sofía": lo que contestaría tu servidor (menú + su IA), sin guardar ni enviar nada. */
export const trySales = (body) => call("/api/vendedora/probar", { method: "POST", body });

// ── Prospectos: contactos nuevos que escribieron por WhatsApp o Messenger ──
/**
 * [{ clave: "wa:521…", canal, id, nombre, primerMensaje, at, importado, y lo que Sofía anotó: autoId, interes, precio,
 *    formaPago, enganche, plazo, mensualidad, cita, quiereAsesor, calor, actualizado }] del más nuevo al más viejo.
 */
export const listLeads = async () => (await call("/api/prospectos")).prospectos;
/** Marca prospectos (por su clave) como ya convertidos en clientes. */
export const updateLead = async (clave, cambios) => (await call("/api/prospectos/actualizar", { method: "POST", body: { clave, ...cambios } })).prospecto;
export const markLeads =(ids, importado = true) => call("/api/prospectos/marcar", { method: "POST", body: { ids, importado } });

// ── Programador de publicaciones (Facebook e Instagram) ──
/** post: { texto, imagen (data URL, JPG para Instagram), cuando (ISO; sin cuando sale de inmediato con la hora del servidor), canales: ["facebook", "instagram"] } */
export const schedulePost = async (post) => (await call("/api/social/programar", { method: "POST", body: { post } })).item;
/** [{ id, texto, imagen (URL), cuando, canales, estado, intentos, resultados { facebook?, instagram? } }] */
export const listQueue = async () => (await call("/api/social/cola")).cola;
export const cancelPost = (id) => call("/api/social/cancelar", { method: "POST", body: { id } });

/** Descarga una foto/documento que el cliente mandó por WhatsApp (lo que no es foto se guarda, nunca se abre). */
export async function downloadMedia(id) {
  const res = await call("/api/media", { params: { id } });
  return res.blob();
}

/** ¿Sigue abierta la ventana de 24 h de WhatsApp? (después solo se permiten plantillas aprobadas) */
export const windowOpen = (lastInAt) => Boolean(lastInAt && Date.now() - new Date(lastInAt).getTime() < 24 * 3600 * 1000);

/** Últimos 10 dígitos: para cruzar el número de WhatsApp con los clientes guardados. */
export const phoneKey = (p) => String(p ?? "").replace(/\D/g, "").slice(-10);
